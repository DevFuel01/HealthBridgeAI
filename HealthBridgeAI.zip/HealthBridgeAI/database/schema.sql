-- HealthBridge AI — Database Schema
-- MySQL 8.0+ | UTF8MB4 | Run once to initialise

SET NAMES utf8mb4;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_ENGINE_SUBSTITUTION';

CREATE DATABASE IF NOT EXISTS `healthbridge_ai`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `healthbridge_ai`;

-- ─── users ────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `users` (
  `id`            INT UNSIGNED     NOT NULL AUTO_INCREMENT,
  `name`          VARCHAR(120)     NOT NULL,
  `email`         VARCHAR(255)     NOT NULL,
  `password_hash` VARCHAR(255)     NOT NULL,
  `role`          ENUM('staff','admin') NOT NULL DEFAULT 'staff',
  `is_active`     TINYINT(1)       NOT NULL DEFAULT 1,
  `last_login`    DATETIME         NULL,
  `created_at`    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── cases ────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `cases` (
  `id`                   INT UNSIGNED     NOT NULL AUTO_INCREMENT,
  `public_case_id`       CHAR(12)         NOT NULL COMMENT 'URL-safe random ID shown to users',
  `patient_name`         VARCHAR(120)     NULL      COMMENT 'Optional; encourage anonymous use',
  `age_band`             ENUM('child','adult','elderly') NOT NULL DEFAULT 'adult',
  `gender`               ENUM('male','female','other','prefer_not') NULL,
  `symptoms_text`        TEXT             NOT NULL,
  `severity`             TINYINT UNSIGNED NOT NULL DEFAULT 1 COMMENT '1=mild … 5=severe',
  `duration`             VARCHAR(60)      NOT NULL COMMENT 'e.g. <24h, 1-3 days, >7 days',
  `comorbidities_json`   JSON             NULL,
  `pregnancy_status`     TINYINT(1)       NOT NULL DEFAULT 0,
  `red_flags_json`       JSON             NULL      COMMENT 'Selected red-flag checklist items',
  `urgency_level`        ENUM('EMERGENCY','URGENT','ROUTINE','SELF-CARE') NOT NULL DEFAULT 'ROUTINE',
  `risk_score`           TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `triggered_rules_json` JSON             NULL,
  `ai_summary`           TEXT             NULL,
  `ai_guidance`          TEXT             NULL,
  `language`             VARCHAR(10)      NOT NULL DEFAULT 'en',
  `status`               ENUM('NEW','REVIEWING','RESOLVED') NOT NULL DEFAULT 'NEW',
  `synced_from_offline`  TINYINT(1)       NOT NULL DEFAULT 0,
  `created_at`           DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`           DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cases_public_id` (`public_case_id`),
  KEY `idx_cases_urgency`    (`urgency_level`),
  KEY `idx_cases_status`     (`status`),
  KEY `idx_cases_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── inventory ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `inventory` (
  `id`          INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `item_name`   VARCHAR(200)  NOT NULL,
  `category`    VARCHAR(80)   NOT NULL DEFAULT 'general',
  `stock_level` INT UNSIGNED  NOT NULL DEFAULT 0,
  `threshold`   INT UNSIGNED  NOT NULL DEFAULT 10   COMMENT 'Low-stock alert threshold',
  `unit`        VARCHAR(30)   NOT NULL DEFAULT 'units',
  `updated_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── audit_logs ───────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `audit_logs` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`    INT UNSIGNED NULL,
  `action`     VARCHAR(80)  NOT NULL,
  `meta_json`  JSON         NULL,
  `ip_address` VARCHAR(45)  NULL,
  `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_audit_user`    (`user_id`),
  KEY `idx_audit_created` (`created_at`),
  CONSTRAINT `fk_audit_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── rate_limits ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `rate_limits` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `ip_address` VARCHAR(45)  NOT NULL,
  `endpoint`   VARCHAR(80)  NOT NULL,
  `hit_count`  INT UNSIGNED NOT NULL DEFAULT 1,
  `window_start` DATETIME   NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rate_ip_endpoint` (`ip_address`, `endpoint`),
  KEY `idx_rate_window` (`window_start`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET foreign_key_checks = 1;

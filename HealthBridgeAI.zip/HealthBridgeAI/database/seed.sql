-- HealthBridge AI — Seed Data
-- Run AFTER schema.sql
-- Demo staff login: staff@healthbridge.ai / Demo1234!

USE `healthbridge_ai`;

-- ─── Demo users ───────────────────────────────────────────────────────────────
-- password_hash of "Demo1234!" using PASSWORD_BCRYPT cost=12
INSERT IGNORE INTO `users` (`name`, `email`, `password_hash`, `role`) VALUES
(
  'Demo Staff',
  'staff@healthbridge.ai',
  '$2y$12$zOO1UXIMoKNHC//O4Lha2eXZOoJjKww/a27j07RgRWpGKNT8svZ.W',
  'staff'
),
(
  'Admin User',
  'admin@healthbridge.ai',
  '$2y$12$zOO1UXIMoKNHC//O4Lha2eXZOoJjKww/a27j07RgRWpGKNT8svZ.W',
  'admin'
);

-- ─── Inventory items ──────────────────────────────────────────────────────────
INSERT IGNORE INTO `inventory` (`item_name`, `category`, `stock_level`, `threshold`, `unit`) VALUES
('Paracetamol 500mg tablets',   'medication',  45,  20, 'tablets'),
('Ibuprofen 400mg tablets',     'medication',   8,  20, 'tablets'),
('Oral Rehydration Salts',      'medication',  32,  15, 'sachets'),
('Antiseptic Wipes',            'wound_care',  60,  25, 'packs'),
('Sterile Bandages (5cm)',      'wound_care',  12,  10, 'rolls'),
('Sterile Bandages (10cm)',     'wound_care',   4,  10, 'rolls'),
('Disposable Gloves (M)',       'ppe',         150,  50, 'pairs'),
('Disposable Gloves (L)',       'ppe',          22,  50, 'pairs'),
('Blood Pressure Cuffs',        'equipment',    3,   2, 'units'),
('Pulse Oximeters',             'equipment',    2,   3, 'units'),
('Thermometers (digital)',      'equipment',    7,   5, 'units'),
('Saline Solution 500ml bags',  'medication',   6,  10, 'bags'),
('Nebuliser Masks (adult)',     'equipment',    5,   4, 'units'),
('Epinephrine auto-injectors',  'emergency',    2,   3, 'units'),
('Face Masks (surgical)',       'ppe',         200,  80, 'units');

-- ─── Sample cases for dashboard demo ─────────────────────────────────────────
INSERT IGNORE INTO `cases`
  (`public_case_id`, `age_band`, `symptoms_text`, `severity`, `duration`,
   `comorbidities_json`, `urgency_level`, `risk_score`,
   `triggered_rules_json`, `ai_summary`, `ai_guidance`, `status`, `created_at`)
VALUES
(
  'DEMO00000001', 'adult',
  'Chest pain radiating to left arm, shortness of breath, sweating',
  5, '<24h',
  '["hypertension","diabetes"]',
  'EMERGENCY', 92,
  '["RED_FLAG:chest_pain_sob","RED_FLAG:radiation","HIGH_SEVERITY","COMORBIDITY:hypertension","COMORBIDITY:diabetes","AGE_BAND:adult"]',
  'Patient reports severe chest pain with radiation to left arm and shortness of breath; high cardiac risk.',
  'CALL EMERGENCY SERVICES (999/112/911) IMMEDIATELY. Do not drive yourself. Chew aspirin 300mg if not allergic. Sit upright and stay calm. Do not eat or drink.',
  'REVIEWING',
  DATE_SUB(NOW(), INTERVAL 2 HOUR)
),
(
  'DEMO00000002', 'child',
  'High fever 39.5°C, vomiting, stiff neck, sensitivity to light',
  4, '<24h',
  '[]',
  'EMERGENCY', 87,
  '["RED_FLAG:meningism_signs","HIGH_SEVERITY","AGE_BAND:child"]',
  'Child presents with high fever, meningism signs (stiff neck + photophobia) — possible meningitis.',
  'Seek EMERGENCY care immediately. This combination of symptoms in a child requires urgent evaluation for meningitis. Keep child comfortable, reduce light exposure.',
  'NEW',
  DATE_SUB(NOW(), INTERVAL 5 HOUR)
),
(
  'DEMO00000003', 'elderly',
  'Sudden confusion, slurred speech, weakness on right side of face',
  4, '<24h',
  '["hypertension","atrial_fibrillation"]',
  'EMERGENCY', 95,
  '["RED_FLAG:stroke_signs","HIGH_SEVERITY","AGE_BAND:elderly","COMORBIDITY:atrial_fibrillation"]',
  'Elderly patient with stroke signs (FAST positive): sudden confusion, facial droop, arm weakness, speech difficulty.',
  'Call emergency services NOW — possible stroke. Note time of symptom onset. Do not give food/drink. Keep patient still and calm.',
  'RESOLVED',
  DATE_SUB(NOW(), INTERVAL 1 DAY)
),
(
  'DEMO00000004', 'adult',
  'Sore throat, mild fever 37.8°C, runny nose, fatigue for 3 days',
  2, '1-3 days',
  '[]',
  'SELF-CARE', 18,
  '["LOW_SEVERITY","SHORT_DURATION","NO_RED_FLAGS"]',
  'Patient reports mild upper respiratory tract infection symptoms — likely viral.',
  'Rest and stay hydrated with plenty of fluids. Paracetamol or ibuprofen for fever/pain relief (follow package instructions). Honey and lemon for sore throat. See a pharmacy if symptoms worsen or persist beyond 7 days.',
  'RESOLVED',
  DATE_SUB(NOW(), INTERVAL 3 DAY)
),
(
  'DEMO00000005', 'adult',
  'Moderate abdominal pain lower right side, nausea, low-grade fever',
  3, '1-3 days',
  '[]',
  'URGENT', 58,
  '["MODERATE_SEVERITY","LOCALISED_ABDO_PAIN","FEVER","DURATION:1-3_days"]',
  'Lower right abdominal pain with fever and nausea — appendicitis cannot be excluded.',
  'Visit your nearest urgent care or A&E today. Avoid food and drink in case surgery is needed. Do not take painkillers that might mask symptoms.',
  'REVIEWING',
  DATE_SUB(NOW(), INTERVAL 6 HOUR)
);

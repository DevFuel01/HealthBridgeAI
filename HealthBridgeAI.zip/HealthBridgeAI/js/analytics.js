/**
 * HealthBridge AI — analytics.js
 * Fetches /api/analytics.php and renders all 5 analytics sections.
 */
document.addEventListener('DOMContentLoaded', async () => {

  // ── Auth check ──────────────────────────────────────────────────────────────
  try {
    const r = await fetch('api/auth.php', {
      method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'check' }),
    });
    const d = await r.json();
    if (!d.logged_in) { location.href = 'staff-login.html'; return; }
  } catch {
    showError('Cannot reach server. Make sure XAMPP Apache is running.');
    return;
  }

  // ── Fetch analytics ─────────────────────────────────────────────────────────
  try {
    const res  = await fetch('api/analytics.php', { credentials: 'same-origin' });
    if (res.status === 401) { location.href = 'staff-login.html'; return; }
    const data = await res.json();
    if (!data.success) throw new Error(data.error || 'Failed to load analytics');

    renderStats(data.totals);
    renderResolution(data.avg_resolution_minutes);
    renderUrgency(data.urgency, data.totals?.total);
    renderTrend(data.trend);
    renderSymptoms(data.symptom_freq);

    document.getElementById('analytics-loading').style.display = 'none';
    document.getElementById('analytics-content').style.display = 'block';

  } catch (err) {
    showError(err.message || 'Failed to load analytics.');
  }
});

// ── Renderers ──────────────────────────────────────────────────────────────────

function renderStats(t) {
  if (!t) return;
  set('stat-total',     t.total     ?? 0);
  set('stat-today',     t.today     ?? 0);
  set('stat-week',      t.this_week ?? 0);
  set('stat-new',       t.new_cases ?? 0);
  set('stat-reviewing', t.reviewing ?? 0);
  set('stat-resolved',  t.resolved  ?? 0);
}

function renderResolution(avgMinutes) {
  const el = document.getElementById('stat-resolution');
  if (!el) return;
  if (avgMinutes === null || avgMinutes === undefined) {
    el.textContent = 'N/A';
    set('stat-resolution-label', 'No resolved cases yet');
    return;
  }
  const mins = Math.round(avgMinutes);
  if (mins < 60) {
    el.textContent = `${mins}m`;
    set('stat-resolution-label', `Average: ${mins} minute${mins !== 1 ? 's' : ''}`);
  } else {
    const hrs  = Math.floor(mins / 60);
    const rem  = mins % 60;
    el.textContent = rem ? `${hrs}h ${rem}m` : `${hrs}h`;
    set('stat-resolution-label', `Average: ${hrs} hour${hrs !== 1 ? 's' : ''} ${rem ? rem + 'm' : ''}`);
  }
}

function renderUrgency(urgency, total) {
  const container = document.getElementById('urgency-bars');
  if (!container) return;

  const levels = [
    { key: 'EMERGENCY', label: '🚨 Emergency', color: 'var(--clr-emergency)' },
    { key: 'URGENT',    label: '⚠ Urgent',     color: 'var(--clr-urgent)'    },
    { key: 'ROUTINE',   label: '🔵 Routine',    color: 'var(--clr-routine)'   },
    { key: 'SELF-CARE', label: '💚 Self-care',  color: 'var(--clr-selfcare)'  },
  ];

  const maxVal = Math.max(...levels.map(l => urgency[l.key] || 0), 1);

  container.innerHTML = levels.map(l => {
    const cnt = urgency[l.key] || 0;
    const pct = Math.round((cnt / maxVal) * 100);
    const pctTotal = total ? Math.round((cnt / total) * 100) : 0;
    return `
      <div class="bar-row" role="listitem" aria-label="${l.label}: ${cnt} cases (${pctTotal}%)">
        <span class="bar-label" style="color:${l.color};">${l.label}</span>
        <div class="bar-track">
          <div class="bar-fill" style="width:${pct}%;background:${l.color};opacity:0.8;" aria-hidden="true"></div>
        </div>
        <span class="bar-count">${cnt} <span style="color:var(--clr-text-dim);font-size:9px;">(${pctTotal}%)</span></span>
      </div>`;
  }).join('');
}

function renderTrend(trend) {
  const container = document.getElementById('trend-chart');
  if (!container || !trend) return;

  const entries = Object.entries(trend);
  const maxVal  = Math.max(...entries.map(([, v]) => v), 1);

  container.innerHTML = entries.map(([day, cnt]) => {
    const heightPct  = Math.round((cnt / maxVal) * 100);
    const shortDate  = day.slice(5); // MM-DD
    const isToday    = day === new Date().toISOString().slice(0, 10);
    const barStyle   = isToday
      ? 'background:var(--clr-primary);opacity:1;box-shadow:0 0 6px var(--clr-primary);'
      : 'background:var(--clr-primary);opacity:0.55;';
    return `
      <div class="trend-col" title="${day}: ${cnt} case${cnt !== 1 ? 's' : ''}">
        <div class="trend-bar" style="height:${heightPct}%;${barStyle}" aria-label="${day}: ${cnt} cases"></div>
        <span class="trend-date">${shortDate}</span>
      </div>`;
  }).join('');
}

function renderSymptoms(freq) {
  const container = document.getElementById('symptom-bars');
  if (!container || !freq) return;

  const entries = Object.entries(freq);
  if (entries.length === 0) {
    container.innerHTML = '<p style="font-size:var(--fs-xs);color:var(--clr-text-muted);">No symptom data available yet.</p>';
    return;
  }

  const maxVal = entries[0][1]; // already sorted descending
  container.innerHTML = entries.map(([kw, cnt]) => {
    const pct = Math.round((cnt / maxVal) * 100);
    return `
      <div class="symptom-row" role="listitem" aria-label="${kw}: ${cnt} occurrences">
        <span class="symptom-name">${escHtml(kw)}</span>
        <div class="symptom-track">
          <div class="symptom-fill" style="width:${pct}%;" aria-hidden="true"></div>
        </div>
        <span class="symptom-count">${cnt}</span>
      </div>`;
  }).join('');
}

// ── Helpers ────────────────────────────────────────────────────────────────────

function set(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}

function showError(msg) {
  document.getElementById('analytics-loading').style.display = 'none';
  const errEl = document.getElementById('analytics-error');
  if (errEl) { errEl.textContent = msg; errEl.style.display = 'block'; }
}

function escHtml(s) {
  return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

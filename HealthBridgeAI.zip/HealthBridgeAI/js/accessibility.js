/**
 * HealthBridge AI — accessibility.js
 * High-contrast, large-text, and simple-language toggles; persisted to localStorage.
 */
document.addEventListener('DOMContentLoaded', () => {
  const body = document.body;

  // ── Restore prefs ────────────────────────────────────────────────────────────
  if (localStorage.getItem('hb-high-contrast') === 'true') body.classList.add('high-contrast');
  if (localStorage.getItem('hb-large-text')    === 'true') body.classList.add('large-text');
  if (localStorage.getItem('hb-simple-lang')   === 'true') {
    body.classList.add('simple-lang');
    applySimpleLanguage(true);
  }

  // Auto-detect very slow connections and enable low-bandwidth if detected
  const connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
  const isSlowConnection = connection && ['slow-2g', '2g'].includes(connection.effectiveType);
  if (isSlowConnection && localStorage.getItem('hb-low-bandwidth') === null) {
    localStorage.setItem('hb-low-bandwidth', 'true');
  }
  if (localStorage.getItem('hb-low-bandwidth') === 'true') {
    body.classList.add('low-bandwidth');
  }
  // Expose globally so triage.js can read it
  window.isLowBandwidth = () => body.classList.contains('low-bandwidth');

  const updateButtonState = (btn, isActive) => {
    if (!btn) return;
    btn.setAttribute('aria-pressed', isActive ? 'true' : 'false');
    btn.style.borderColor = isActive ? 'var(--clr-primary)' : '';
    btn.style.color       = isActive ? 'var(--clr-primary)' : '';
  };

  const contrastBtn  = document.getElementById('contrast-toggle');
  const textBtn      = document.getElementById('text-size-toggle');
  const simpleBtn    = document.getElementById('simple-lang-toggle');
  const bandwidthBtn = document.getElementById('low-bandwidth-toggle');

  updateButtonState(contrastBtn,  body.classList.contains('high-contrast'));
  updateButtonState(textBtn,      body.classList.contains('large-text'));
  updateButtonState(simpleBtn,    body.classList.contains('simple-lang'));
  updateButtonState(bandwidthBtn, body.classList.contains('low-bandwidth'));

  // ── High Contrast ─────────────────────────────────────────────────────────────
  if (contrastBtn) {
    contrastBtn.addEventListener('click', () => {
      const active = body.classList.toggle('high-contrast');
      localStorage.setItem('hb-high-contrast', active);
      updateButtonState(contrastBtn, active);
      showToast(active ? 'High contrast enabled' : 'High contrast disabled', 'info', 2000);
    });
  }

  // ── Large Text ────────────────────────────────────────────────────────────────
  if (textBtn) {
    textBtn.addEventListener('click', () => {
      const active = body.classList.toggle('large-text');
      localStorage.setItem('hb-large-text', active);
      updateButtonState(textBtn, active);
      showToast(active ? 'Large text enabled' : 'Large text disabled', 'info', 2000);
    });
  }

  // ── Low Bandwidth ─────────────────────────────────────────────────────────────
  if (bandwidthBtn) {
    bandwidthBtn.addEventListener('click', () => {
      const active = body.classList.toggle('low-bandwidth');
      localStorage.setItem('hb-low-bandwidth', active);
      updateButtonState(bandwidthBtn, active);
      showToast(
        active
          ? '📶 Low bandwidth on — AI analysis skipped to save data'
          : 'Low bandwidth off — full AI analysis enabled',
        'info', 3000
      );
    });
  }

  // ── Simple Language ───────────────────────────────────────────────────────────
  if (simpleBtn) {
    simpleBtn.addEventListener('click', () => {
      const active = body.classList.toggle('simple-lang');
      localStorage.setItem('hb-simple-lang', active);
      updateButtonState(simpleBtn, active);
      applySimpleLanguage(active);
      showToast(active ? 'Simple language on — plain words used' : 'Full language restored', 'info', 2500);
    });
  }
});

/**
 * Swap text content of all [data-full] / [data-simple] elements.
 * Elements use:  data-full="Medical term"  data-simple="Plain word"
 */
function applySimpleLanguage(useSimple) {
  document.querySelectorAll('[data-simple]').forEach(el => {
    const full   = el.getAttribute('data-full')   || el.textContent;
    const simple = el.getAttribute('data-simple') || el.textContent;
    // Store full text the first time
    if (!el.getAttribute('data-full')) {
      el.setAttribute('data-full', el.textContent.trim());
    }
    el.textContent = useSimple ? simple : full;
  });
}

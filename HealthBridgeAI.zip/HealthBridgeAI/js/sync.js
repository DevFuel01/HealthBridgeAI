/**
 * HealthBridge AI — sync.js
 * IndexedDB offline queue + sync management.
 * Exports window.SyncManager used by other modules.
 */

const DB_NAME    = 'healthbridge-offline';
const STORE_NAME = 'pending-cases';
const DB_VERSION = 1;

let _db = null;

async function openDb() {
  if (_db) return _db;
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = (e) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: 'offline_id' });
        store.createIndex('synced', 'synced', { unique: false });
      }
    };
    req.onsuccess = (e) => { _db = e.target.result; resolve(_db); };
    req.onerror   = (e) => reject(e.target.error);
  });
}

async function queueCase(caseData) {
  const db    = await openDb();
  const offlineId = 'offline_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8);
  const record = { ...caseData, offline_id: offlineId, synced: 0, queued_at: new Date().toISOString() };
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    tx.objectStore(STORE_NAME).add(record);
    tx.oncomplete = () => resolve(offlineId);
    tx.onerror    = (e) => reject(e.target.error);
  });
}

async function getPending() {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx    = db.transaction(STORE_NAME, 'readonly');
    const req   = tx.objectStore(STORE_NAME).index('synced').getAll(0);
    req.onsuccess = () => resolve(req.result);
    req.onerror   = (e) => reject(e.target.error);
  });
}

async function markSynced(offlineId) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx    = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const get   = store.get(offlineId);
    get.onsuccess = () => {
      const record = get.result;
      if (record) { record.synced = 1; store.put(record); }
      resolve();
    };
    get.onerror = (e) => reject(e.target.error);
  });
}

async function getPendingCount() {
  const pending = await getPending().catch(() => []);
  return pending.length;
}

async function updateSyncBadge() {
  const count  = await getPendingCount();
  const badges = document.querySelectorAll('#sync-count');
  badges.forEach(b => { b.textContent = count; b.style.display = count > 0 ? 'inline-flex' : 'none'; });
  return count;
}

async function syncPending() {
  if (!navigator.onLine) {
    showToast('Still offline — sync will run when connected.', 'info');
    return;
  }
  const pending = await getPending().catch(() => []);
  if (pending.length === 0) {
    showToast('No pending cases to sync.', 'info');
    return;
  }

  try {
    const res  = await fetch('api/sync.php', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ cases: pending }),
    });
    const data = await res.json();

    if (data.success) {
      for (const result of (data.results || [])) {
        if (result.success) await markSynced(result.offline_id);
      }
      await updateSyncBadge();
      showToast(`✓ Synced ${data.processed} case(s) successfully.`, 'success');
    } else {
      showToast('Sync failed. Try again shortly.', 'error');
    }
  } catch {
    showToast('Sync error — check your connection.', 'error');
  }
}

// Auto-sync when coming back online
window.addEventListener('online', async () => {
  const count = await getPendingCount();
  if (count > 0) { await syncPending(); }
});

// Expose globally
window.SyncManager = { queueCase, getSyncCount: getPendingCount, updateSyncBadge, syncPending };

// Init badge on load
document.addEventListener('DOMContentLoaded', () => updateSyncBadge());

/**
 * HealthBridge AI — case-detail.js
 * Load and display a single case; update status.
 */
document.addEventListener('DOMContentLoaded', async () => {
  const id = new URLSearchParams(location.search).get('id');
  if (!id) { location.href = 'dashboard.html'; return; }

  // Auth check
  try {
    const authRes = await fetch('api/auth.php', {
      method: 'POST',
      credentials: 'same-origin',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ action: 'check' }),
    });
    const authData = await authRes.json();
    if (!authData.logged_in) { window.location.href = 'staff-login.html'; return; }
  } catch { window.location.href = 'staff-login.html'; return; }

  try {
    const res  = await fetch(`api/cases.php?id=${encodeURIComponent(id)}`, {
      credentials: 'same-origin',
    });
    if (res.status === 401) { location.href = 'staff-login.html'; return; }
    const data = await res.json();
    if (!data.success) throw new Error(data.error || 'Case not found');

    const c   = data.case;
    const low = data.low_stock || [];

    // ── Low stock banner ────────────────────────────────────────────────────
    if (low.length > 0) {
      const banner   = document.getElementById('low-stock-banner');
      const list     = document.getElementById('low-stock-list');
      banner.style.display = 'block';
      list.innerHTML = low.map(i => `<li>⚠ <strong>${escHtml(i.item_name)}</strong> — ${i.stock_level} ${i.stock_level === 1 ? 'unit' : 'units'} left (threshold: ${i.threshold})</li>`).join('');
    }

    // ── Case header ─────────────────────────────────────────────────────────
    const set = (id, txt) => { const el = document.getElementById(id); if (el) el.textContent = txt || '—'; };
    set('case-public-id',  c.public_case_id);
    set('case-created-at', formatDate(c.created_at));
    set('case-symptoms-text', c.symptoms_text);
    set('case-severity',   `${c.severity}/5`);
    set('case-duration',   c.duration);
    set('case-age-band',   c.age_band);
    set('case-pregnancy',  c.pregnancy_status ? 'Yes' : 'No');
    set('case-ai-summary', c.ai_summary || 'No AI summary available.');
    set('case-ai-guidance',c.ai_guidance || 'No AI guidance available.');

    // Urgency badge
    const urgencyBadge = document.getElementById('case-urgency-badge');
    if (urgencyBadge) {
      urgencyBadge.innerHTML = `<span class="badge badge--${(c.urgency_level||'').toLowerCase().replace('-','').replace(' ','')}" style="font-size:var(--fs-sm);">${c.urgency_level}</span>`;
    }
    const statusBadge = document.getElementById('case-status-badge');
    if (statusBadge) {
      statusBadge.innerHTML = `<span class="badge badge--${(c.status||'').toLowerCase()}">${c.status}</span>`;
    }

    // Risk score circle
    const riskCircle = document.getElementById('risk-score-circle');
    if (riskCircle) {
      const score = parseInt(c.risk_score) || 0;
      const color = score >= 85 ? 'var(--clr-emergency)' : score >= 55 ? 'var(--clr-urgent)' : score >= 25 ? 'var(--clr-routine)' : 'var(--clr-selfcare)';
      riskCircle.textContent = score;
      riskCircle.style.color = color;
      riskCircle.style.borderColor = color;
    }
    set('risk-description', c.urgency_level === 'EMERGENCY' ? 'Critical risk level' : c.urgency_level === 'URGENT' ? 'Elevated risk' : 'Moderate or low risk');

    // Comorbidities
    const comorbidities = Array.isArray(c.comorbidities_json) ? c.comorbidities_json : [];
    if (comorbidities.length) {
      document.getElementById('case-comorbidities-wrap').style.display = 'block';
      document.getElementById('case-comorbidities').innerHTML = comorbidities.map(c => `<span class="badge badge--routine">${escHtml(c)}</span>`).join('');
    }

    // Red flags
    const redFlags = Array.isArray(c.red_flags_json) ? c.red_flags_json : [];
    if (redFlags.length) {
      document.getElementById('case-red-flags-wrap').style.display = 'block';
      document.getElementById('case-red-flags').innerHTML = redFlags.map(f => `<span class="badge badge--emergency">${escHtml(f)}</span>`).join('');
    }

    // Triggered rules
    const rules = Array.isArray(c.triggered_rules_json) ? c.triggered_rules_json : [];
    const rulesDom = document.getElementById('case-triggered-rules');
    if (rulesDom && rules.length) {
      rulesDom.innerHTML = rules.map(r => `<span class="badge badge--${r.startsWith('RED_FLAG') ? 'emergency' : 'routine'}">${escHtml(r)}</span>`).join('');
    }

    // ── Status update ───────────────────────────────────────────────────────
    ['new', 'reviewing', 'resolved'].forEach(s => {
      const btn = document.getElementById(`status-${s}`);
      if (!btn) return;
      if (s === (c.status || '').toLowerCase()) {
        btn.classList.add('btn--primary');
        btn.setAttribute('aria-pressed', 'true');
      }
      btn.addEventListener('click', async () => {
        if (btn.disabled) return;
        btn.disabled = true;
        const newStatus = btn.dataset.status;
        try {
          const r = await fetch('api/cases.php', {
            method: 'PATCH',
            credentials: 'same-origin',
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ id: c.id, status: newStatus }),
          });
          const d = await r.json();
          if (d.success) {
            ['new','reviewing','resolved'].forEach(x => {
              const b = document.getElementById(`status-${x}`);
              if (b) { b.classList.remove('btn--primary'); b.setAttribute('aria-pressed','false'); }
            });
            btn.classList.add('btn--primary');
            btn.setAttribute('aria-pressed', 'true');
            document.getElementById('status-success').style.display = 'block';
            if (statusBadge) statusBadge.innerHTML = `<span class="badge badge--${newStatus.toLowerCase()}">${newStatus}</span>`;
            showToast(`Status updated to ${newStatus}`, 'success');
          } else {
            showToast(d.error || 'Failed to update status.', 'error');
          }
        } catch (err) {
          showToast(err.message || 'Failed to update status.', 'error');
        } finally {
          btn.disabled = false;
        }
      });
    });

    document.getElementById('case-loading').style.display = 'none';
    document.getElementById('case-content').style.display  = 'block';

    // Load history timeline after main content is shown
    fetchAndRenderHistory(c.id);

  } catch (err) {
    document.getElementById('case-loading').style.display = 'none';
    const errEl = document.getElementById('case-error');
    errEl.textContent = err.message || 'Failed to load case.';
    errEl.classList.add('show');
  }
});

/**
 * Fetch and render the case status-change history timeline.
 * @param {number} caseId — internal integer case id
 */
async function fetchAndRenderHistory(caseId) {
  const loadingEl = document.getElementById('case-history-loading');
  const listEl    = document.getElementById('case-history-list');
  const emptyEl   = document.getElementById('case-history-empty');

  const STATUS_ICONS = { NEW: '🔵', REVIEWING: '📋', RESOLVED: '✅' };
  const STATUS_COLORS = {
    NEW:       'var(--clr-routine)',
    REVIEWING: 'var(--clr-urgent)',
    RESOLVED:  'var(--clr-selfcare)',
  };

  try {
    const res  = await fetch(`api/cases.php?id=${encodeURIComponent(caseId)}&history=1`, {
      credentials: 'same-origin',
    });
    const data = await res.json();
    if (!data.success) throw new Error(data.error || 'Failed to load history');

    loadingEl.style.display = 'none';
    const events = data.events || [];

    if (events.length === 0) {
      emptyEl.style.display = 'block';
      return;
    }

    listEl.style.display = 'block';
    listEl.innerHTML = events.map((ev, i) => {
      const icon  = STATUS_ICONS[ev.new_status]  || '🔄';
      const color = STATUS_COLORS[ev.new_status] || 'var(--clr-text-muted)';
      const isLast = i === events.length - 1;
      return `
        <li style="display:flex;gap:var(--sp-3);padding-bottom:${isLast ? '0' : 'var(--sp-4)'};position:relative;">
          ${!isLast ? `<div style="position:absolute;left:10px;top:22px;bottom:0;width:2px;background:var(--clr-border);"></div>` : ''}
          <div style="flex-shrink:0;width:22px;height:22px;border-radius:50%;background:var(--clr-surface-raised);border:2px solid ${color};display:flex;align-items:center;justify-content:center;font-size:0.7rem;position:relative;z-index:1;">
            ${icon}
          </div>
          <div style="padding-top:1px;">
            <p style="font-size:var(--fs-sm);font-weight:600;color:${color};margin:0;">
              Status set to <strong>${escHtml(ev.new_status)}</strong>
            </p>
            <p style="font-size:var(--fs-xs);color:var(--clr-text-muted);margin:var(--sp-1) 0 0;">
              ${escHtml(ev.staff_name)} &middot; ${formatDate(ev.created_at)}
            </p>
          </div>
        </li>`;
    }).join('');
  } catch (err) {
    if (loadingEl) loadingEl.textContent = 'Could not load history.';
  }
}

function formatDate(dt) {
  if (!dt) return '';
  return new Date((dt + '').replace(' ','T')).toLocaleString('en-GB', { dateStyle:'medium', timeStyle:'short' });
}
function escHtml(s) {
  return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

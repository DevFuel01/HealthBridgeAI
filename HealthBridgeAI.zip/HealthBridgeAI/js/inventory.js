/**
 * HealthBridge AI — inventory.js
 * Staff inventory view + inline stock level update.
 */
document.addEventListener('DOMContentLoaded', async () => {

  // ── Auth check ───────────────────────────────────────────────────────────────
  try {
    const authRes  = await fetch('api/auth.php', {
      method:      'POST',
      credentials: 'same-origin',
      headers:     { 'Content-Type': 'application/json' },
      body:        JSON.stringify({ action: 'check' }),
    });
    const authData = await authRes.json();
    if (!authData.logged_in) { location.href = 'staff-login.html'; return; }
  } catch {
    // True network failure — don't redirect, just show error
    document.getElementById('inv-loading').style.display = 'none';
    const errEl = document.getElementById('inv-error');
    errEl.textContent = 'Cannot reach server. Make sure XAMPP Apache is running.';
    errEl.style.display = 'block';
    return;
  }

  // ── Load inventory ───────────────────────────────────────────────────────────
  try {
    const res = await fetch('api/inventory.php', { credentials: 'same-origin' });

    if (res.status === 401) { location.href = 'staff-login.html'; return; }

    let data = {};
    try {
      data = await res.json();
    } catch {
      throw new Error(`Server error (HTTP ${res.status}). Check XAMPP MySQL and database import.`);
    }

    if (!data.success) throw new Error(data.error || 'Failed to load inventory');

    const items = data.items || [];
    const total  = items.length;
    const low    = items.filter(i => i.is_low).length;
    const ok     = total - low;

    document.getElementById('inv-stat-total').textContent = total;
    document.getElementById('inv-stat-low').textContent   = low;
    document.getElementById('inv-stat-ok').textContent    = ok;

    const tbody = document.getElementById('inv-tbody');
    items.forEach(item => {
      const tr  = document.createElement('tr');
      const isLow = item.is_low;
      tr.innerHTML = `
        <td style="font-weight:500;">${escHtml(item.item_name)}</td>
        <td><span class="badge badge--routine" style="font-size:10px;">${escHtml(item.category)}</span></td>
        <td class="${isLow ? 'low-stock' : ''}">${item.stock_level} <span style="font-size:var(--fs-xs);color:var(--clr-text-muted);">${escHtml(item.unit)}</span></td>
        <td style="color:var(--clr-text-muted);">${item.threshold}</td>
        <td>${isLow ? '<span class="badge badge--emergency">⚠ Low</span>' : '<span class="badge badge--selfcare">✓ OK</span>'}</td>
        <td>
          <div style="display:flex;gap:var(--sp-2);align-items:center;">
            <input type="number" min="0" max="99999" value="${item.stock_level}"
                   class="inv-stock-input" data-id="${item.id}"
                   aria-label="Update stock level for ${escHtml(item.item_name)}" />
            <button class="btn btn--sm btn--primary save-stock-btn" data-id="${item.id}"
                    aria-label="Save stock level for ${escHtml(item.item_name)}">Save</button>
          </div>
        </td>`;
      tbody.appendChild(tr);
    });

    // Save button delegation
    tbody.addEventListener('click', async (e) => {
      const btn = e.target.closest('.save-stock-btn');
      if (!btn) return;
      const itemId   = parseInt(btn.dataset.id);
      const input    = tbody.querySelector(`.inv-stock-input[data-id="${itemId}"]`);
      if (!input) return;
      const newStock = parseInt(input.value);
      if (isNaN(newStock) || newStock < 0) { showToast('Invalid stock level.', 'error'); return; }

      btn.disabled    = true;
      btn.textContent = '…';
      try {
        const r = await fetch('api/inventory.php', {
          method:      'PATCH',
          credentials: 'same-origin',
          headers:     { 'Content-Type': 'application/json' },
          body:        JSON.stringify({ id: itemId, stock_level: newStock }),
        });

        let d = {};
        try { d = await r.json(); } catch { throw new Error(`HTTP ${r.status}`); }

        if (d.success) {
          showToast('Stock updated!', 'success');
          setTimeout(() => location.reload(), 800);
        } else {
          showToast(d.error || 'Update failed.', 'error');
        }
      } catch (err) {
        showToast(err.message || 'Network error.', 'error');
      } finally {
        btn.disabled    = false;
        btn.textContent = 'Save';
      }
    });

    document.getElementById('inv-loading').style.display = 'none';
    document.getElementById('inv-content').style.display = 'block';

  } catch (err) {
    document.getElementById('inv-loading').style.display = 'none';
    const errEl = document.getElementById('inv-error');
    errEl.textContent = err.message || 'Failed to load inventory.';
    errEl.style.display = 'block';
  }
});

function escHtml(s) {
  return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

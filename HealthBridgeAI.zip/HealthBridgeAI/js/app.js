/**
 * HealthBridge AI — app.js
 * Core init: offline detection, toast, staff login form handler.
 */

// ── Toast utility ─────────────────────────────────────────────────────────────
window.showToast = function(msg, type = 'info', durationMs = 3500) {
  const container = document.getElementById('toast-container');
  if (!container) return;
  const toast = document.createElement('div');
  toast.className = `toast toast--${type}`;
  toast.textContent = msg;
  toast.setAttribute('role', 'status');
  container.appendChild(toast);
  setTimeout(() => toast.remove(), durationMs);
};

// ── Offline banner ────────────────────────────────────────────────────────────
function updateOfflineBanner() {
  const banner = document.getElementById('offline-banner');
  if (!banner) return;
  if (!navigator.onLine) {
    banner.classList.add('show');
  } else {
    banner.classList.remove('show');
  }
}
window.addEventListener('online',  updateOfflineBanner);
window.addEventListener('offline', updateOfflineBanner);

// ── Accessibility panel toggle ────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  updateOfflineBanner();

  const a11yToggle = document.getElementById('a11y-toggle');
  const a11yPanel  = document.getElementById('a11y-panel');
  if (a11yToggle && a11yPanel) {
    a11yToggle.addEventListener('click', () => {
      const isHidden = a11yPanel.style.display === 'none';
      a11yPanel.style.display = isHidden ? 'block' : 'none';
      a11yToggle.setAttribute('aria-expanded', isHidden ? 'true' : 'false');
    });
    a11yToggle.setAttribute('aria-expanded', 'false');
    a11yToggle.setAttribute('aria-controls', 'a11y-panel');
  }

  // ── Staff login form (used on staff-login.html) ───────────────────────────
  const loginForm = document.getElementById('login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email    = document.getElementById('email').value.trim();
      const password = document.getElementById('password').value;
      const alertEl  = document.getElementById('login-alert');
      const btn      = document.getElementById('login-btn');
      const label    = document.getElementById('login-label');
      const spinner  = document.getElementById('login-spinner');

      alertEl.classList.remove('show');

      if (!email || !password) {
        document.getElementById('email-error').style.display    = email    ? 'none' : 'block';
        document.getElementById('password-error').style.display = password ? 'none' : 'block';
        return;
      }

      btn.disabled          = true;
      label.style.display   = 'none';
      spinner.style.display = 'block';

      try {
        const res = await fetch('api/auth.php', {
          method:      'POST',
          credentials: 'same-origin',
          headers:     { 'Content-Type': 'application/json' },
          body:        JSON.stringify({ action: 'login', email, password }),
        });

        // Parse JSON separately so we can show a useful message if PHP crashes
        let data = {};
        try {
          data = await res.json();
        } catch {
          alertEl.textContent = `Server error (HTTP ${res.status}). Make sure XAMPP MySQL is running and schema.sql + seed.sql have been imported.`;
          alertEl.classList.add('show');
          return;
        }

        if (data.success) {
          window.location.href = 'dashboard.html';
        } else {
          alertEl.textContent = data.error || 'Invalid credentials. Try staff@healthbridge.ai / Demo1234!';
          alertEl.classList.add('show');
        }
      } catch {
        // True network failure — Apache not started
        alertEl.textContent = 'Cannot reach the server. Make sure XAMPP Apache is started.';
        alertEl.classList.add('show');
      } finally {
        btn.disabled          = false;
        label.style.display   = 'inline';
        spinner.style.display = 'none';
      }
    });
  }

  // ── Logout button ─────────────────────────────────────────────────────────
  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', async () => {
      await fetch('api/auth.php', {
        method:      'POST',
        credentials: 'same-origin',
        headers:     { 'Content-Type': 'application/json' },
        body:        JSON.stringify({ action: 'logout' }),
      }).catch(() => {});
      window.location.href = 'staff-login.html';
    });
  }

  // ── Sync-now button ───────────────────────────────────────────────────────
  const syncBtn = document.getElementById('sync-now-btn');
  if (syncBtn) {
    syncBtn.addEventListener('click', async () => {
      if (window.SyncManager) {
        await window.SyncManager.syncPending();
      }
    });
  }
});

// ── Service Worker registration ───────────────────────────────────────────────
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js')
      .then(() => console.log('[SW] Registered'))
      .catch(err => console.warn('[SW] Registration failed:', err));
  });
}

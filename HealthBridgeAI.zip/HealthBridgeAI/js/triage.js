/**
 * HealthBridge AI — triage.js
 * 3-step form, voice input, submit with online/offline branching.
 */
document.addEventListener('DOMContentLoaded', () => {
  let currentStep = 1;
  const severityLabels = ['', 'Mild (1)', 'Mild (2)', 'Moderate (3)', 'Severe (4)', 'Very Severe (5)'];

  // ── Stepper navigation ──────────────────────────────────────────────────────
  function showStep(step) {
    [1, 2, 3].forEach(s => {
      document.getElementById(`step-${s}`).style.display = s === step ? 'block' : 'none';
      const ind = document.getElementById(`step-indicator-${s}`);
      ind.classList.remove('active', 'done');
      if (s === step) ind.classList.add('active');
      if (s < step)  ind.classList.add('done');
    });
    document.getElementById('stepper')?.setAttribute('aria-valuenow', step);
    document.getElementById(`step-indicator-${step}`)?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    currentStep = step;
  }

  document.getElementById('next-1')?.addEventListener('click', () => {
    const symptoms = document.getElementById('symptoms-text').value.trim();
    if (symptoms.length < 3) {
      document.getElementById('symptoms-error').style.display = 'block';
      document.getElementById('symptoms-text').focus();
      return;
    }
    document.getElementById('symptoms-error').style.display = 'none';
    showStep(2);
  });
  document.getElementById('next-2')?.addEventListener('click', () => showStep(3));
  document.getElementById('back-1')?.addEventListener('click', () => showStep(1));
  document.getElementById('back-2')?.addEventListener('click', () => showStep(2));

  // ── Severity slider ─────────────────────────────────────────────────────────
  const severityInput   = document.getElementById('severity');
  const severityDisplay = document.getElementById('severity-display');
  if (severityInput) {
    const update = () => {
      const v = parseInt(severityInput.value);
      severityDisplay.textContent = severityLabels[v] || v;
      severityInput.setAttribute('aria-valuenow', v);
      severityInput.setAttribute('aria-valuetext', severityLabels[v]);
    };
    severityInput.addEventListener('input', update);
    update();
  }

  // ── Voice input ─────────────────────────────────────────────────────────────
  const voiceBtn    = document.getElementById('voice-btn');
  const symptomsBox = document.getElementById('symptoms-text');
  let recognition   = null;

  if (voiceBtn) {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      voiceBtn.style.display = 'none';
      const hint = document.getElementById('symptoms-hint');
      if (hint) hint.textContent = 'Voice input not supported in this browser. Please type your symptoms.';
    } else {
      recognition = new SpeechRecognition();
      recognition.continuous    = false;
      recognition.interimResults = true;
      recognition.lang          = 'en-US';

      let isListening = false;
      voiceBtn.addEventListener('click', () => {
        if (isListening) { recognition.stop(); return; }
        recognition.start();
        isListening = true;
        voiceBtn.classList.add('listening');
        voiceBtn.textContent = '🔴 Stop';
        voiceBtn.setAttribute('aria-label', 'Stop voice recording');
      });

      recognition.onresult = (e) => {
        let transcript = '';
        for (let i = e.resultIndex; i < e.results.length; i++) {
          transcript += e.results[i][0].transcript;
        }
        symptomsBox.value = transcript;
        document.getElementById('symptoms-error').style.display = 'none';
      };

      recognition.onend = () => {
        isListening = false;
        voiceBtn.classList.remove('listening');
        voiceBtn.textContent = '🎤 Voice';
        voiceBtn.setAttribute('aria-label', 'Use voice input to describe symptoms');
      };

      recognition.onerror = (e) => {
        recognition.stop();
        let msg = 'Voice input error. Please type symptoms instead.';
        if (e.error === 'not-allowed') msg = 'Microphone access denied. Please allow microphone access or type symptoms.';
        showToast(msg, 'error');
      };
    }
  }

  // ── Form submit ─────────────────────────────────────────────────────────────
  const form = document.getElementById('triage-form');
  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      // Build payload
      const symptoms = document.getElementById('symptoms-text').value.trim();
      if (symptoms.length < 3) {
        document.getElementById('form-error-global').textContent = 'Please describe your symptoms (Step 1).';
        document.getElementById('form-error-global').classList.add('show');
        showStep(1);
        return;
      }
      document.getElementById('form-error-global').classList.remove('show');

      const comorbidities  = [...document.querySelectorAll('input[name="comorbidities"]:checked')].map(el => el.value);
      const selectedRedFlags = [...document.querySelectorAll('input[name="red_flags"]:checked')].map(el => el.value);

      const lowBw = typeof window.isLowBandwidth === 'function' && window.isLowBandwidth();
      const payload = {
        symptoms_text:     symptoms,
        severity:          parseInt(document.getElementById('severity').value),
        duration:          document.getElementById('duration').value,
        age_band:          document.getElementById('age-band').value,
        gender:            document.getElementById('gender').value || undefined,
        pregnancy_status:  document.getElementById('pregnancy').checked,
        comorbidities,
        red_flags:         selectedRedFlags,
        patient_name:      document.getElementById('patient-name').value.trim(),
        language:          document.getElementById('language-select').value,
        healthcare_access: document.getElementById('healthcare-access')?.value || 'full',
        low_bandwidth:     lowBw,
      };
      if (lowBw) showToast('📶 Low bandwidth mode — using rules engine only (no AI call)', 'info', 3500);

      // Disable submit
      const submitBtn    = document.getElementById('submit-btn');
      const submitLabel  = document.getElementById('submit-label');
      const submitSpinner= document.getElementById('submit-spinner');
      submitBtn.disabled        = true;
      submitLabel.style.display = 'none';
      submitSpinner.style.display = 'flex';

      if (!navigator.onLine) {
        // Queue offline
        try {
          const offlineId = await window.SyncManager.queueCase(payload);
          await window.SyncManager.updateSyncBadge();
          // Create a local result for display
          const { RulesEngineLocal } = await import('./rules-engine-local.js').catch(() => ({ RulesEngineLocal: null }));
          sessionStorage.setItem('hb-result', JSON.stringify({
            offline_id:    offlineId,
            urgency_level: 'ROUTINE',
            risk_score:    0,
            is_emergency:  false,
            ai_guidance:   'Your case has been queued offline and will be processed when you reconnect. For emergencies, call 999/911/112 now.',
            first_aid_steps: ['Stay calm.', 'If this is an emergency, call 999 / 911 / 112 immediately.', 'Your case is saved and will be submitted when connectivity is restored.'],
            triggered_rules: ['OFFLINE_QUEUE'],
            explainer: 'Offline mode — case queued for sync.',
            crisis_resources: [],
            used_ai_fallback: true,
            queued_offline: true,
          }));
          showToast('Case saved offline. Will sync when connected.', 'info');
          setTimeout(() => { window.location.href = 'results.html'; }, 1200);
        } catch {
          showToast('Failed to save offline case.', 'error');
          submitBtn.disabled          = false;
          submitLabel.style.display   = 'inline';
          submitSpinner.style.display = 'none';
        }
        return;
      }

      // Online: post to API
      try {
        const res  = await fetch('api/triage.php', {
          method:  'POST',
          headers: { 'Content-Type': 'application/json' },
          body:    JSON.stringify(payload),
        });

        if (res.status === 429) {
          throw new Error('Too many requests. Please wait a minute and try again.');
        }
        const data = await res.json();

        if (!data.success) {
          throw new Error(data.error || 'Triage failed. Please try again.');
        }

        sessionStorage.setItem('hb-result', JSON.stringify(data));
        window.location.href = 'results.html';
      } catch (err) {
        const errBox = document.getElementById('form-error-global');
        errBox.textContent = err.message || 'Something went wrong. Please try again.';
        errBox.classList.add('show');
        submitBtn.disabled          = false;
        submitLabel.style.display   = 'inline';
        submitSpinner.style.display = 'none';
      }
    });
  }

  showStep(1);
});

/**
 * HealthBridge AI — dashboard.js
 * Staff case list with filters, pagination, stats.
 */
document.addEventListener('DOMContentLoaded', async () => {

  // ── Auth check ───────────────────────────────────────────────────────────────
  try {
    const authRes = await fetch('api/auth.php', {
      method:      'POST',
      credentials: 'same-origin',
      headers:     { 'Content-Type': 'application/json' },
      body:        JSON.stringify({ action: 'check' }),
    });

    let authData = {};
    try { authData = await authRes.json(); } catch { authData = {}; }

    if (!authData.logged_in) { window.location.href = 'staff-login.html'; return; }

    const welcomeEl = document.getElementById('welcome-msg');
    if (welcomeEl && authData.user) welcomeEl.textContent = `Welcome back, ${authData.user.name}`;
  } catch {
    window.location.href = 'staff-login.html'; return;
  }

  let currentPage = 1;
  const state = { urgency: '', status: '', date_from: '', date_to: '' };

  // ── Load cases ───────────────────────────────────────────────────────────────
  async function loadCases() {
    const loading = document.getElementById('cases-loading');
    const list    = document.getElementById('cases-list');
    const errorEl = document.getElementById('cases-error');
    loading.style.display = 'block';
    list.innerHTML        = '';
    errorEl.style.display = 'none';
    errorEl.textContent   = '';

    const params = new URLSearchParams({ page: currentPage });
    if (state.urgency)   params.append('urgency',   state.urgency);
    if (state.status)    params.append('status',    state.status);
    if (state.date_from) params.append('date_from', state.date_from);
    if (state.date_to)   params.append('date_to',   state.date_to);

    try {
      const res = await fetch(`api/cases.php?${params}`, { credentials: 'same-origin' });

      if (res.status === 401) { window.location.href = 'staff-login.html'; return; }

      let data = {};
      try {
        data = await res.json();
      } catch {
        throw new Error(`Server error (HTTP ${res.status}). Check XAMPP MySQL and confirm schema.sql was imported.`);
      }

      loading.style.display = 'none';

      if (!data.success) {
        errorEl.textContent   = data.error || 'Failed to load cases.';
        errorEl.style.display = 'block';
        return;
      }

      // Stats (shown on first unfiltered page)
      if (currentPage === 1 && !state.urgency && !state.status) {
        document.getElementById('stat-total').textContent     = data.total;
        const emergency = (data.cases || []).filter(c => c.urgency_level === 'EMERGENCY').length;
        const urgent    = (data.cases || []).filter(c => c.urgency_level === 'URGENT').length;
        const newCount  = (data.cases || []).filter(c => c.status === 'NEW').length;
        document.getElementById('stat-emergency').textContent = emergency;
        document.getElementById('stat-urgent').textContent    = urgent;
        document.getElementById('stat-new').textContent       = newCount;
      }

      // Pagination
      const pageInfo   = document.getElementById('page-info');
      const prevBtn    = document.getElementById('prev-page');
      const nextBtn    = document.getElementById('next-page');
      const totalPages = Math.ceil((data.total || 0) / (data.per_page || 20)) || 1;
      pageInfo.textContent  = `Page ${data.page} of ${totalPages} (${data.total} cases)`;
      prevBtn.disabled      = data.page <= 1;
      nextBtn.disabled      = data.page >= totalPages;
      document.getElementById('pagination').style.display = data.total > (data.per_page || 20) ? 'flex' : 'none';

      if (!data.cases || data.cases.length === 0) {
        list.innerHTML = '<p style="color:var(--clr-text-muted);text-align:center;padding:var(--sp-8);">No cases found for these filters.</p>';
        return;
      }

      data.cases.forEach(c => {
        const snippet = (c.symptoms_text || '').slice(0, 80) + ((c.symptoms_text || '').length > 80 ? '…' : '');
        const item    = document.createElement('a');
        item.href      = `case-detail.html?id=${c.id}`;
        item.className = 'case-row';
        item.setAttribute('role',       'listitem');
        item.setAttribute('aria-label', `Case ${c.public_case_id}, ${c.urgency_level}, ${c.status}`);
        item.innerHTML = `
          <div>
            <div style="display:flex;align-items:center;gap:var(--sp-2);margin-bottom:var(--sp-1);">
              <span style="font-family:monospace;font-size:var(--fs-sm);font-weight:700;color:var(--clr-primary);">${escHtml(c.public_case_id)}</span>
              <span class="badge badge--routine">${escHtml(c.age_band)}</span>
              <span>Severity: ${c.severity}/5</span>
            </div>
            <p class="case-row__snippet">${escHtml(snippet)}</p>
          </div>
          <div class="case-row__right">
            <span class="badge badge--${(c.urgency_level || '').toLowerCase().replace(/[^a-z]/g, '')}">${c.urgency_level}</span>
            <span class="badge badge--${(c.status || '').toLowerCase()}">${c.status}</span>
            <span class="case-row__date">${formatDate(c.created_at)}</span>
          </div>`;
        list.appendChild(item);
      });

    } catch (err) {
      loading.style.display = 'none';
      errorEl.textContent   = err.message || 'Network error loading cases.';
      errorEl.style.display = 'block';
    }
  }

  // ── Filters ──────────────────────────────────────────────────────────────────
  document.getElementById('apply-filters').addEventListener('click', () => {
    state.urgency   = document.getElementById('filter-urgency').value;
    state.status    = document.getElementById('filter-status').value;
    state.date_from = document.getElementById('filter-date-from').value;
    state.date_to   = document.getElementById('filter-date-to').value;
    currentPage = 1;
    loadCases();
  });
  document.getElementById('clear-filters').addEventListener('click', () => {
    ['filter-urgency', 'filter-status', 'filter-date-from', 'filter-date-to'].forEach(id => {
      document.getElementById(id).value = '';
    });
    state.urgency = state.status = state.date_from = state.date_to = '';
    currentPage = 1;
    loadCases();
  });
  document.getElementById('prev-page').addEventListener('click', () => {
    if (currentPage > 1) { currentPage--; loadCases(); }
  });
  document.getElementById('next-page').addEventListener('click', () => { currentPage++; loadCases(); });

  // ── Low stock alert ───────────────────────────────────────────────────────────
  (async () => {
    try {
      const res = await fetch('api/inventory.php', { credentials: 'same-origin' });
      if (!res.ok) return;
      let data = {};
      try { data = await res.json(); } catch { return; }
      if (data.success) {
        const low = (data.items || []).filter(i => i.is_low);
        if (low.length > 0) {
          const alert = document.getElementById('low-stock-alert');
          if (alert) { alert.textContent = `⚠ ${low.length} low-stock item(s)`; alert.style.display = 'inline-flex'; }
        }
      }
    } catch { /* best-effort */ }
  })();

  await loadCases();
});

function formatDate(dt) {
  if (!dt) return '';
  const d = new Date((dt + '').replace(' ', 'T') + 'Z');
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
}
function escHtml(s) {
  return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

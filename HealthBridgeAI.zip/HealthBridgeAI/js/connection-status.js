/**
 * HealthBridge AI — connection-status.js
 * Injects a slim status banner that reacts to online/offline events in real time.
 * Reads SyncManager (sync.js) for pending case count if available.
 */
(function () {
  // ── Inject banner element ────────────────────────────────────────────────────
  const banner = document.createElement('div');
  banner.id = 'conn-banner';
  banner.setAttribute('role', 'status');
  banner.setAttribute('aria-live', 'polite');
  banner.setAttribute('aria-atomic', 'true');
  Object.assign(banner.style, {
    position:       'fixed',
    top:            '0',
    left:           '0',
    right:          '0',
    zIndex:         '99999',
    padding:        '6px 16px',
    fontSize:       '0.8rem',
    fontWeight:     '600',
    textAlign:      'center',
    display:        'none',
    transition:     'opacity 0.3s ease',
    letterSpacing:  '0.02em',
  });
  document.body.prepend(banner);

  let hideTimer = null;

  function showBanner(msg, bg, textColor, autohideMs) {
    clearTimeout(hideTimer);
    banner.textContent = msg;
    banner.style.background = bg;
    banner.style.color       = textColor;
    banner.style.display     = 'block';
    banner.style.opacity     = '1';
    if (autohideMs) {
      hideTimer = setTimeout(() => {
        banner.style.opacity = '0';
        setTimeout(() => { banner.style.display = 'none'; }, 350);
      }, autohideMs);
    }
  }

  function hideBanner() {
    clearTimeout(hideTimer);
    banner.style.opacity = '0';
    setTimeout(() => { banner.style.display = 'none'; }, 350);
  }

  // ── Determine initial state ───────────────────────────────────────────────────
  async function refresh() {
    if (!navigator.onLine) {
      await showOffline();
    } else {
      hideBanner();
    }
  }

  async function showOffline() {
    let queueMsg = '';
    if (window.SyncManager) {
      try {
        const count = await window.SyncManager.getSyncCount();
        if (count > 0) queueMsg = ` · ${count} case${count > 1 ? 's' : ''} queued`;
      } catch (_) { /* sync.js may not be loaded on all pages */ }
    }
    showBanner(
      `🔴 You are offline${queueMsg} — triage results will be saved and synced when you reconnect`,
      '#1a0a08',
      '#ff8f8f',
      null   // stay visible
    );
  }

  // ── Online / offline events ───────────────────────────────────────────────────
  window.addEventListener('offline', () => showOffline());

  window.addEventListener('online', async () => {
    let syncMsg = '';
    if (window.SyncManager) {
      try {
        const count = await window.SyncManager.getSyncCount();
        if (count > 0) syncMsg = ` · syncing ${count} queued case${count > 1 ? 's' : ''}…`;
      } catch (_) { /* ignore */ }
    }
    showBanner(
      `🟢 Back online${syncMsg}`,
      '#071a0f',
      '#6ee7b7',
      4000   // auto-hide after 4 s
    );
  });

  // ── Init ──────────────────────────────────────────────────────────────────────
  document.addEventListener('DOMContentLoaded', () => refresh());
})();

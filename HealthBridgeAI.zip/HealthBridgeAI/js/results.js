/**
 * HealthBridge AI — results.js
 * Renders triage result from sessionStorage. TTS + emergency overlay.
 */
document.addEventListener('DOMContentLoaded', () => {
  const raw = sessionStorage.getItem('hb-result');
  const loading = document.getElementById('results-loading');
  const errorEl = document.getElementById('results-error');
  const content = document.getElementById('results-content');

  if (!raw) {
    loading.style.display = 'none';
    errorEl.style.display = 'block';
    return;
  }

  let result;
  try { result = JSON.parse(raw); } catch { loading.style.display = 'none'; errorEl.style.display = 'block'; return; }

  // ── Render urgency card ───────────────────────────────────────────────────
  const urgency    = (result.urgency_level || 'ROUTINE').toUpperCase();
  const urgencyMap = {
    EMERGENCY: { icon: '🚨', label: 'EMERGENCY', cls: 'emergency', color: 'var(--clr-emergency)', sub: 'Call emergency services immediately.' },
    URGENT:    { icon: '⚠',  label: 'URGENT',    cls: 'urgent',    color: 'var(--clr-urgent)',    sub: 'Seek medical attention today.' },
    ROUTINE:   { icon: '🔵', label: 'ROUTINE',   cls: 'routine',   color: 'var(--clr-routine)',   sub: 'See a doctor in the next 1–3 days.' },
    'SELF-CARE':{ icon: '🟢',label: 'SELF-CARE', cls: 'self-care', color: 'var(--clr-selfcare)',  sub: 'Rest and self-care at home.' },
  };
  const meta = urgencyMap[urgency] || urgencyMap.ROUTINE;

  const cardHtml = `
    <div class="urgency-card ${meta.cls}" role="region" aria-label="Urgency level: ${meta.label}">
      <div class="urgency-card__icon" aria-hidden="true">${meta.icon}</div>
      <div class="urgency-card__title">${meta.label}</div>
      <p class="urgency-card__sub">${meta.sub}</p>
    </div>`;
  document.getElementById('urgency-card-container').innerHTML = cardHtml;

  // ── Risk gauge ────────────────────────────────────────────────────────────
  const score = parseInt(result.risk_score) || 0;
  const gaugeArc = document.getElementById('gauge-arc');
  const arcTotal = 172; // full arc length
  const dashArr  = `${Math.round((score / 100) * arcTotal)} ${arcTotal}`;
  const scoreColor = score >= 85 ? 'var(--clr-emergency)' : score >= 55 ? 'var(--clr-urgent)' : score >= 25 ? 'var(--clr-routine)' : 'var(--clr-selfcare)';
  if (gaugeArc) {
    gaugeArc.setAttribute('stroke-dasharray', dashArr);
    gaugeArc.setAttribute('stroke', scoreColor);
  }
  const scoreEl = document.getElementById('risk-score-value');
  if (scoreEl) { scoreEl.textContent = score; scoreEl.style.color = scoreColor; }

  // ── Case ID ───────────────────────────────────────────────────────────────
  const caseIdEl = document.getElementById('case-id-display');
  const caseId   = result.public_case_id || (result.queued_offline ? '[Queued offline]' : 'N/A');
  if (caseIdEl) caseIdEl.textContent = caseId;

  document.getElementById('copy-case-id')?.addEventListener('click', () => {
    navigator.clipboard?.writeText(caseId).then(() => showToast('Case ID copied!', 'success', 2000));
  });

  // ── AI Guidance ───────────────────────────────────────────────────────────
  const guidanceEl = document.getElementById('ai-guidance-text');
  if (guidanceEl) guidanceEl.textContent = result.ai_guidance || result.guidance || 'No guidance available.';
  if (result.used_ai_fallback) {
    const badge = document.getElementById('ai-fallback-badge');
    if (badge) badge.style.display = 'inline-flex';
  }

  // ── Steps list ────────────────────────────────────────────────────────────
  const steps = result.first_aid_steps || [];
  const stepsList = document.getElementById('steps-list');
  if (stepsList && steps.length) {
    stepsList.innerHTML = steps.map((s, i) => `
      <div class="step-item">
        <div class="step-item__num" aria-hidden="true">${i + 1}</div>
        <p class="step-item__text">${escHtml(s)}</p>
      </div>`).join('');
  }

  // ── Crisis resources ──────────────────────────────────────────────────────
  const crisis = result.crisis_resources || [];
  if (crisis.length) {
    const crisisBox  = document.getElementById('crisis-box');
    const crisisList = document.getElementById('crisis-list');
    if (crisisBox && crisisList) {
      crisisBox.style.display = 'block';
      crisisList.innerHTML = crisis.map(r => `<li>${escHtml(r)}</li>`).join('');
    }
  }

  // ── What to monitor ───────────────────────────────────────────────────────
  renderGuidanceList(
    result.what_to_monitor || [],
    'monitor-card', 'monitor-list',
    '👁', 'var(--clr-routine)'
  );

  // ── What makes it worse ───────────────────────────────────────────────────
  renderGuidanceList(
    result.what_makes_worse || [],
    'worse-card', 'worse-list',
    '🚫', 'var(--clr-urgent)'
  );

  // ── When to escalate ──────────────────────────────────────────────────────
  renderGuidanceList(
    result.when_to_escalate || [],
    'escalate-card', 'escalate-list',
    '🚦', 'var(--clr-urgent)'
  );

  // ── Triggered rules ───────────────────────────────────────────────────────
  const rulesExplainer = document.getElementById('rules-explainer');
  if (rulesExplainer) rulesExplainer.textContent = result.explainer || '';
  const rulesList = document.getElementById('triggered-rules-list');
  if (rulesList) {
    (result.triggered_rules || []).forEach(rule => {
      const span = document.createElement('span');
      span.className = 'badge badge--' + (rule.startsWith('RED_FLAG') ? 'emergency' : 'routine');
      span.textContent = rule;
      rulesList.appendChild(span);
    });
  }

  // ── TTS ───────────────────────────────────────────────────────────────────
  let utterance = null;
  const synth   = window.speechSynthesis;
  const ttsText = [meta.label + ' level.', result.ai_guidance || '', ...(steps.map((s, i) => `Step ${i + 1}. ${s}`))].join(' ');

  const ttsPlay = document.getElementById('tts-play');
  const ttsStop = document.getElementById('tts-stop');
  const ttsStatus = document.getElementById('tts-status');

  if (ttsPlay) {
    if (!synth) {
      ttsPlay.disabled = true;
      if (ttsStatus) ttsStatus.textContent = 'TTS not supported in this browser.';
    } else {
      ttsPlay.addEventListener('click', () => {
        if (synth.speaking) { synth.cancel(); }
        utterance = new SpeechSynthesisUtterance(ttsText);
        utterance.lang  = 'en-US';
        utterance.rate  = 0.9;
        utterance.onstart = () => { ttsStatus.textContent = 'Reading…'; ttsStop.disabled = false; ttsPlay.disabled = true; };
        utterance.onend   = () => { ttsStatus.textContent = ''; ttsStop.disabled = true; ttsPlay.disabled = false; };
        utterance.onerror = () => { ttsStatus.textContent = ''; ttsStop.disabled = true; ttsPlay.disabled = false; };
        synth.speak(utterance);
      });
      ttsStop.addEventListener('click', () => { synth.cancel(); });
    }
  }

  // ── Emergency overlay ─────────────────────────────────────────────────────
  if (urgency === 'EMERGENCY') {
    document.getElementById('emergency-overlay').classList.add('show');
    document.getElementById('emergency-overlay').focus();
    document.getElementById('emergency-dismiss')?.addEventListener('click', () => {
      document.getElementById('emergency-overlay').classList.remove('show');
      document.getElementById('results-content').focus();
    });
    // Auto-start TTS for emergency
    if (synth && !result.queued_offline) {
      setTimeout(() => ttsPlay?.click(), 1200);
    }
  }

  // ── Print ─────────────────────────────────────────────────────────────────
  document.getElementById('print-btn')?.addEventListener('click', () => window.print());

  // ── Show content ──────────────────────────────────────────────────────────
  loading.style.display = 'none';
  content.style.display = 'block';
});

function escHtml(str) {
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

/**
 * Show a guidance card and populate its list.
 * @param {string[]} items  - array of strings
 * @param {string} cardId   - element ID of the card wrapper
 * @param {string} listId   - element ID of the <ul>
 * @param {string} icon     - emoji prefix for each item
 * @param {string} color    - CSS color for the icon
 */
function renderGuidanceList(items, cardId, listId, icon, color) {
  if (!items || !items.length) return;
  const card = document.getElementById(cardId);
  const list = document.getElementById(listId);
  if (!card || !list) return;
  list.innerHTML = items.map(item => `
    <li style="display:flex;align-items:flex-start;gap:var(--sp-2);font-size:var(--fs-sm);">
      <span aria-hidden="true" style="color:${color};flex-shrink:0;margin-top:1px;">${icon}</span>
      <span>${escHtml(item)}</span>
    </li>`).join('');
  card.style.display = 'block';
}

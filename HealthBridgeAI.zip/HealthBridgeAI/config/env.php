<?php

declare(strict_types=1);
/**
 * HealthBridge AI — Environment Loader
 * Reads .env file from project root into $_ENV / getenv().
 */

function loadEnv(string $path): void
{
    if (!file_exists($path)) {
        return; // silently skip; rely on system env vars in production
    }

    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#')) {
            continue;
        }
        if (!str_contains($line, '=')) {
            continue;
        }
        [$key, $value] = explode('=', $line, 2);
        $key   = trim($key);
        $value = trim($value);
        // Strip surrounding quotes
        if (preg_match('/^(["\'])(.*)\\1$/', $value, $m)) {
            $value = $m[2];
        }
        if (!array_key_exists($key, $_ENV)) {
            $_ENV[$key] = $value;
            putenv("{$key}={$value}");
        }
    }
}

// Auto-load on include
loadEnv(dirname(__DIR__) . '/.env');

function env(string $key, mixed $default = null): mixed
{
    return $_ENV[$key] ?? getenv($key) ?: $default;
}

// ── Safe error handling — never expose PHP errors to HTTP responses ────────────
// Log everything, display nothing (regardless of php.ini defaults).
error_reporting(E_ALL);
ini_set('log_errors', '1');
ini_set('display_errors', env('APP_DEBUG', 'false') === 'true' ? '1' : '0');
ini_set('display_startup_errors', '0');

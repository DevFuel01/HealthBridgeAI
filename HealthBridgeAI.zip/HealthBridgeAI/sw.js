/**
 * HealthBridge AI — Service Worker
 * Cache-first for app shell, network-first for API calls.
 */

const CACHE_NAME    = 'healthbridge-v1';
const OFFLINE_URL   = '/HealthBridgeAI/offline.html';
const APP_SHELL = [
  '/HealthBridgeAI/',
  '/HealthBridgeAI/index.html',
  '/HealthBridgeAI/triage.html',
  '/HealthBridgeAI/results.html',
  '/HealthBridgeAI/dashboard.html',
  '/HealthBridgeAI/case-detail.html',
  '/HealthBridgeAI/inventory.html',
  '/HealthBridgeAI/analytics.html',
  '/HealthBridgeAI/offline.html',
  '/HealthBridgeAI/staff-login.html',
  '/HealthBridgeAI/css/main.css',
  '/HealthBridgeAI/css/accessibility.css',
  '/HealthBridgeAI/js/app.js',
  '/HealthBridgeAI/js/accessibility.js',
  '/HealthBridgeAI/js/sync.js',
  '/HealthBridgeAI/js/triage.js',
  '/HealthBridgeAI/js/results.js',
  '/HealthBridgeAI/js/dashboard.js',
  '/HealthBridgeAI/js/case-detail.js',
  '/HealthBridgeAI/js/inventory.js',
  '/HealthBridgeAI/js/analytics.js',
  '/HealthBridgeAI/js/connection-status.js',
  '/HealthBridgeAI/manifest.json',
  '/HealthBridgeAI/icons/icon.svg',
];

// ── Install: pre-cache app shell ─────────────────────────────────────────────
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(APP_SHELL))
  );
  self.skipWaiting();
});

// ── Activate: purge old caches ───────────────────────────────────────────────
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// ── Fetch strategy ────────────────────────────────────────────────────────────
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Network-first for API calls
  if (url.pathname.includes('/api/')) {
    event.respondWith(
      fetch(request)
        .then(res => res)
        .catch(() => new Response(
          JSON.stringify({ error: 'Offline — request queued locally.' }),
          { status: 503, headers: { 'Content-Type': 'application/json' } }
        ))
    );
    return;
  }

  // Cache-first for app shell + static assets
  event.respondWith(
    caches.match(request).then(cached => {
      if (cached) return cached;
      return fetch(request)
        .then(response => {
          if (response && response.status === 200 && response.type === 'basic') {
            const resp = response.clone();
            caches.open(CACHE_NAME).then(cache => cache.put(request, resp));
          }
          return response;
        })
        .catch(() => {
          // Serve offline fallback for HTML navigations
          if (request.headers.get('accept')?.includes('text/html')) {
            return caches.match(OFFLINE_URL);
          }
        });
    })
  );
});

// ── Background sync (if supported) ───────────────────────────────────────────
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-cases') {
    event.waitUntil(
      self.clients.matchAll().then(clients => {
        clients.forEach(client => client.postMessage({ type: 'SYNC_REQUESTED' }));
      })
    );
  }
});

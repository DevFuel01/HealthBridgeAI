<?php

declare(strict_types=1);
/**
 * HealthBridge AI — Deterministic Rules Engine
 *
 * This is the safety-critical triage layer. It ALWAYS runs first.
 * Gemini AI may NOT override the urgency level produced here.
 */

class RulesEngine
{
    // ──────────────────────────────────────────────────────────────────────────
    // Public entry point
    // ──────────────────────────────────────────────────────────────────────────

    /**
     * @param array $input {
     *   symptoms_text: string,
     *   severity: int 1-5,
     *   duration: string,
     *   age_band: 'child'|'adult'|'elderly',
     *   pregnancy_status: bool,
     *   comorbidities: string[],
     *   red_flags: string[],
     * }
     * @return array {
     *   urgency_level: string,
     *   risk_score: int,
     *   triggered_rules: string[],
     *   explainer: string,
     *   is_emergency: bool,
     *   first_aid_steps: string[],
     *   crisis_resources: string[],
     * }
     */
    public static function evaluate(array $input): array
    {
        $triggered = [];
        $score     = 0;

        // ── 1. Normalise inputs ───────────────────────────────────────────────
        $symptomsText    = strtolower(trim($input['symptoms_text'] ?? ''));
        $severity        = max(1, min(5, (int)($input['severity'] ?? 1)));
        $duration        = strtolower(trim($input['duration'] ?? ''));
        $ageBand         = $input['age_band'] ?? 'adult';
        $isPregnant      = (bool)($input['pregnancy_status'] ?? false);
        $comorbidities   = array_map('strtolower', (array)($input['comorbidities'] ?? []));
        $selectedRedFlags = array_map('strtolower', (array)($input['red_flags'] ?? []));

        // ── 2. Red-flag text patterns ─────────────────────────────────────────
        $redFlagPatterns = [
            // Cardiac
            'cardiac_chest_sob'    => ['chest pain', 'chest tightness', 'shortness of breath', 'difficulty breathing'],
            'cardiac_arm_jaw'      => ['left arm pain', 'jaw pain', 'arm radiating'],
            // Stroke (FAST)
            'stroke_face'          => ['face drooping', 'facial droop', 'face droops', 'asymmetrical face'],
            'stroke_arm'           => ['arm weakness', 'arm numb', 'arm cannot lift', 'arm paralysis'],
            'stroke_speech'        => ['slurred speech', 'speech difficulty', 'cannot speak', 'confused speech'],
            'stroke_sudden'        => ['sudden confusion', 'sudden headache', 'sudden severe headache'],
            // Meningitis
            'meningism'            => ['stiff neck', 'neck stiffness', 'sensitivity to light', 'photophobia', 'purple rash', 'non-blanching rash'],
            // Severe bleeding
            'severe_bleed'         => ['severe bleeding', 'uncontrolled bleeding', 'blood loss', 'spurting blood'],
            // Consciousness
            'unconscious'          => ['unconscious', 'unresponsive', 'collapsed', 'passed out', 'not waking'],
            // Seizure
            'seizure'              => ['seizure', 'convulsion', 'fitting', 'epileptic'],
            // Anaphylaxis
            'anaphylaxis'          => ['anaphylaxis', 'throat swelling', 'throat closing', 'tongue swelling', 'severe allergic'],
            // Dehydration
            'severe_dehydration'   => ['severe dehydration', 'no urine', 'sunken eyes', 'dry mouth and no tears', 'extreme thirst and dizzy'],
            // Mental health crisis
            'suicidal'             => ['suicidal', 'want to die', 'end my life', 'self harm', 'hurt myself', 'kill myself'],
            // Obstetric
            'obstetric_emergency'  => ['heavy bleeding in pregnancy', 'baby not moving', 'eclampsia', 'severe headache in pregnancy', 'preeclampsia'],
        ];

        $criticalFlags = [
            'cardiac_chest_sob',
            'stroke_face',
            'stroke_arm',
            'stroke_speech',
            'stroke_sudden',
            'meningism',
            'severe_bleed',
            'unconscious',
            'seizure',
            'anaphylaxis',
            'severe_dehydration',
            'suicidal',
            'obstetric_emergency',
            'cardiac_arm_jaw',
        ];

        $detectedRedFlags = [];
        foreach ($redFlagPatterns as $flagKey => $keywords) {
            foreach ($keywords as $kw) {
                if (
                    str_contains($symptomsText, $kw) ||
                    in_array($kw, $selectedRedFlags, true) ||
                    in_array($flagKey, $selectedRedFlags, true)
                ) {
                    $detectedRedFlags[] = $flagKey;
                    $triggered[]        = "RED_FLAG:{$flagKey}";
                    break;
                }
            }
        }

        // Check user-selected red flags directly
        $directRedFlagMap = [
            'chest_pain'          => 'cardiac_chest_sob',
            'difficulty_breathing' => 'cardiac_chest_sob',
            'stroke_symptoms'     => 'stroke_face',
            'unconscious'         => 'unconscious',
            'seizure'             => 'seizure',
            'severe_bleeding'     => 'severe_bleed',
            'anaphylaxis'         => 'anaphylaxis',
            'suicidal_thoughts'   => 'suicidal',
        ];
        foreach ($selectedRedFlags as $rf) {
            if (isset($directRedFlagMap[$rf]) && !in_array($directRedFlagMap[$rf], $detectedRedFlags, true)) {
                $detectedRedFlags[] = $directRedFlagMap[$rf];
                $triggered[]        = "RED_FLAG:{$directRedFlagMap[$rf]}_selected";
            }
        }
        $detectedRedFlags = array_unique($detectedRedFlags);

        $hasCriticalFlag = !empty(array_intersect($detectedRedFlags, $criticalFlags));

        // ── 3. Severity score ────────────────────────────────────────────────
        $severityScore = match ($severity) {
            1 => 5,
            2 => 15,
            3 => 30,
            4 => 50,
            5 => 70,
            default => 5,
        };
        if ($severity >= 4) {
            $triggered[] = 'HIGH_SEVERITY';
        }
        if ($severity === 3) {
            $triggered[] = 'MODERATE_SEVERITY';
        }
        if ($severity <= 2) {
            $triggered[] = 'LOW_SEVERITY';
        }
        $score += $severityScore;

        // ── 4. Duration score ────────────────────────────────────────────────
        $durationScore = match (true) {
            str_contains($duration, '<24')      => 5,
            str_contains($duration, '1-3')      => 10,
            str_contains($duration, '3-7')      => 15,
            str_contains($duration, '>7')       => 20,
            str_contains($duration, 'weeks')    => 25,
            default                             => 8,
        };
        $triggered[] = "DURATION:{$duration}";
        $score      += $durationScore;

        // ── 5. Age band multiplier ───────────────────────────────────────────
        $ageMultiplier = match ($ageBand) {
            'child'   => 1.3,
            'elderly' => 1.4,
            default   => 1.0,
        };
        $triggered[] = "AGE_BAND:{$ageBand}";

        // ── 6. Comorbidity bonus ─────────────────────────────────────────────
        $comorbidityRisk = [
            'diabetes'              => 8,
            'heart_disease'         => 12,
            'hypertension'          => 6,
            'asthma'                => 5,
            'copd'                  => 10,
            'immunocompromised'     => 10,
            'cancer'                => 8,
            'liver_disease'         => 8,
            'kidney_disease'        => 8,
            'atrial_fibrillation'   => 10,
            'stroke_history'        => 10,
            'obesity'               => 4,
        ];
        $comorbidityScore = 0;
        foreach ($comorbidities as $c) {
            $c = str_replace([' ', '-'], '_', $c);
            if (isset($comorbidityRisk[$c])) {
                $comorbidityScore += $comorbidityRisk[$c];
                $triggered[]       = "COMORBIDITY:{$c}";
            }
        }
        $score += min($comorbidityScore, 20);

        // ── 7. Pregnancy ─────────────────────────────────────────────────────
        if ($isPregnant) {
            $score      += 8;
            $triggered[] = 'PREGNANCY';
        }

        // ── 8. Red-flag boost ────────────────────────────────────────────────
        if ($hasCriticalFlag) {
            $score       = 100; // Hard cap: emergency
            $triggered[] = 'CRITICAL_RED_FLAG_OVERRIDE';
        } elseif (!empty($detectedRedFlags)) {
            $score      += count($detectedRedFlags) * 15;
        } else {
            $triggered[] = 'NO_RED_FLAGS';
        }

        // ── 9. Compute final score + urgency ─────────────────────────────────
        $score = (int) min(100, round($score * $ageMultiplier));

        $urgencyLevel = match (true) {
            $hasCriticalFlag || $score >= 85 => 'EMERGENCY',
            $score >= 55                     => 'URGENT',
            $score >= 25                     => 'ROUTINE',
            default                          => 'SELF-CARE',
        };

        // ── 10. First-aid steps by urgency ───────────────────────────────────
        $firstAidSteps = self::getFirstAidSteps($urgencyLevel, $detectedRedFlags, $isPregnant);

        // ── 11. Crisis resources ──────────────────────────────────────────────
        $crisisResources = [];
        if (in_array('suicidal', $detectedRedFlags, true)) {
            $crisisResources = [
                '☎ International Association for Suicide Prevention: https://www.iasp.info/resources/Crisis_Centres/',
                '☎ Crisis Text Line (US): Text HOME to 741741',
                '☎ Samaritans (UK): 116 123',
                '☎ Lifeline (AU): 13 11 14',
                'If in immediate danger: Call your local emergency number (999 / 911 / 112)',
            ];
        }

        // ── 12. Explainer text ───────────────────────────────────────────────
        $explainer = self::buildExplainer($urgencyLevel, $score, $triggered, $detectedRedFlags);

        return [
            'urgency_level'   => $urgencyLevel,
            'risk_score'      => $score,
            'triggered_rules' => array_unique($triggered),
            'explainer'       => $explainer,
            'is_emergency'    => ($urgencyLevel === 'EMERGENCY'),
            'first_aid_steps' => $firstAidSteps,
            'crisis_resources' => $crisisResources,
        ];
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Private helpers
    // ──────────────────────────────────────────────────────────────────────────

    private static function getFirstAidSteps(string $urgency, array $redFlags, bool $pregnant): array
    {
        if (in_array('suicidal', $redFlags, true)) {
            return [
                'Stay with the person or stay on the phone with them.',
                'Listen without judgment and remove access to means if safe to do so.',
                'Contact crisis support or emergency services immediately.',
                'Do not leave them alone until professional help arrives.',
            ];
        }
        if (in_array('cardiac_chest_sob', $redFlags, true)) {
            return [
                'Call emergency services (999/911/112) immediately.',
                'Help the person sit in a comfortable position (upright or half-sitting).',
                'Loosen any tight clothing around the neck and chest.',
                'If aspirin is available and not allergic: give 300mg to chew (adults only).',
                'Stay with the person. Do not let them eat or drink.',
                'Be ready to perform CPR if they become unconscious and stop breathing.',
            ];
        }
        if (in_array('stroke_face', $redFlags, true) || in_array('stroke_speech', $redFlags, true)) {
            return [
                'Call emergency services immediately — possible stroke.',
                'Note the exact time symptoms started.',
                'Ask the person to smile, raise both arms, repeat a short sentence (FAST test).',
                'Keep them calm and still. Do not give food or drink.',
                'If unconscious and breathing: place in recovery position.',
            ];
        }
        if (in_array('anaphylaxis', $redFlags, true)) {
            return [
                'Call emergency services immediately.',
                'Use epinephrine auto-injector (EpiPen) if available.',
                'Lay the person flat with legs raised (unless breathing is difficult — then sit upright).',
                'A second EpiPen dose may be given after 5 minutes if no improvement.',
                'Even if symptoms improve, they MUST be evaluated at a hospital.',
            ];
        }
        if (in_array('seizure', $redFlags, true)) {
            return [
                'Call emergency services if seizure lasts more than 5 minutes, or this is their first seizure.',
                'Stay with the person. Clear the area of hard objects.',
                'Do NOT restrain them or put anything in their mouth.',
                'Gently cushion their head.',
                'After the seizure: place in recovery position if unconscious.',
                'Time the duration of the seizure.',
            ];
        }
        if (in_array('severe_bleed', $redFlags, true)) {
            return [
                'Call emergency services immediately.',
                'Apply firm, direct pressure to the wound using a clean cloth or bandage.',
                'Do not remove the cloth — add more on top if it soaks through.',
                'Elevate the injured area above heart level if possible.',
                'Keep the person warm and still. Treat for shock.',
            ];
        }

        return match ($urgency) {
            'EMERGENCY' => [
                'Call emergency services (999/911/112) immediately.',
                'Do not drive yourself to hospital.',
                'Stay calm and follow the emergency operator\'s instructions.',
                'If safe to do so, unlock the door for paramedics.',
            ],
            'URGENT' => [
                'Seek medical attention today — visit urgent care or an emergency department.',
                'Do not wait to see if symptoms improve on their own.',
                'Bring a list of any medications you are taking.',
                'If symptoms worsen rapidly, call emergency services.',
            ],
            'ROUTINE' => [
                'Book an appointment with your GP or clinic within the next 1–3 days.',
                'Monitor your symptoms and rest.',
                'Stay hydrated and take over-the-counter pain relief if appropriate.',
                'If symptoms change significantly, reassess using this tool or call a nurse helpline.',
            ],
            default => [ // SELF-CARE
                'Rest and recover at home.',
                'Stay well hydrated with water and clear fluids.',
                'Take paracetamol or ibuprofen as directed on the packaging for pain/fever.',
                'Seek pharmacy advice for minor ailments.',
                'Return to this tool or see a doctor if symptoms worsen over the next 48 hours.',
            ],
        };
    }

    private static function buildExplainer(string $urgency, int $score, array $triggered, array $redFlags): string
    {
        $ruleCount = count($triggered);
        $flagList  = empty($redFlags) ? 'none detected' : implode(', ', $redFlags);
        return "Triage level {$urgency} assigned based on risk score {$score}/100. "
            . "{$ruleCount} rule(s) evaluated. Critical flags: {$flagList}. "
            . "This assessment is performed by a deterministic rules engine and is not a medical diagnosis.";
    }
}

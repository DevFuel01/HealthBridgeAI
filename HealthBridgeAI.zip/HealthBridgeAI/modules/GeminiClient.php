<?php

declare(strict_types=1);
/**
 * HealthBridge AI — Gemini API Client (Server-side only)
 *
 * IMPORTANT: API key is NEVER sent to the browser.
 * Gemini is an ASSISTIVE layer only. It cannot override the rules engine.
 */

define('GEMINI_API_ENDPOINT', 'https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent');
define('GEMINI_API_MODEL',    'gemini-2.5-flash');

class GeminiClient
{
    private string $apiKey;
    private string $endpoint;
    private int    $timeoutSeconds;

    public function __construct()
    {
        $this->apiKey         = env('GEMINI_API_KEY', '');
        $this->endpoint       = GEMINI_API_ENDPOINT;
        $this->timeoutSeconds = 15;
    }

    /**
     * Generate patient-friendly guidance based on rules engine output.
     *
     * @param array $triageData {
     *   symptoms_text:   string,
     *   urgency_level:   string,
     *   risk_score:      int,
     *   triggered_rules: string[],
     *   age_band:        string,
     *   comorbidities:   string[],
     *   language:        string,  // 'en' | 'fr' | 'es' | 'ar' | etc.
     * }
     * @return array { normalized_symptoms: string, guidance: string, language_note: string, used_fallback: bool }
     */
    public function generateGuidance(array $triageData): array
    {
        if (empty($this->apiKey)) {
            return $this->fallback($triageData);
        }

        $prompt = $this->buildPrompt($triageData);

        try {
            $response = $this->callApi($prompt);
            $parsed   = $this->parseResponse($response);
            if ($parsed === null) {
                return $this->fallback($triageData);
            }
            $parsed['used_fallback'] = false;
            return $parsed;
        } catch (\Throwable $e) {
            error_log('[GeminiClient] Error: ' . $e->getMessage());
            return $this->fallback($triageData);
        }
    }

    /**
     * Public wrapper to get fallback guidance without attempting the API.
     * Used in low-bandwidth mode to conserve network resources.
     */
    public function getFallbackOnly(array $data): array
    {
        return $this->fallback(array_merge([
            'urgency_level'    => $data['urgency_level'] ?? 'ROUTINE',
            'healthcare_access' => $data['healthcare_access'] ?? 'full',
        ], $data));
    }

    // ──────────────────────────────────────────────────────────────────────────

    private function buildPrompt(array $data): string
    {
        $urgency      = $data['urgency_level'];
        $score        = $data['risk_score'];
        $symptoms     = htmlspecialchars($data['symptoms_text'], ENT_QUOTES, 'UTF-8');
        $ageBand      = $data['age_band'];
        $comorbids    = implode(', ', $data['comorbidities'] ?? []) ?: 'none reported';
        $rules        = implode(', ', $data['triggered_rules'] ?? []);
        $language     = $data['language'] ?? 'en';
        $langLabel    = $language !== 'en' ? "Respond in language code: {$language} (translate guidance text only; keep JSON keys in English)." : 'Respond in English.';
        $access       = $data['healthcare_access'] ?? 'full';
        $accessLabel  = match ($access) {
            'clinic'   => 'The patient has access to a clinic or GP only (no emergency services nearby).',
            'pharmacy' => 'The patient has access to a pharmacy or community health worker ONLY. No hospital or clinic is available.',
            'none'     => 'The patient has NO access to any nearby medical facility. Suggest only home-based or remotely accessible care.',
            default    => 'The patient has full access to hospital and emergency services.',
        };

        return <<<PROMPT
        You are HealthBridge AI, a medical triage support assistant integrated into a healthcare guidance system.
        
        SYSTEM INSTRUCTIONS (NON-NEGOTIABLE):
        1. You MUST NOT provide a definitive medical diagnosis.
        2. You MUST NOT override the urgency level already determined by the rules engine.
        3. You MUST include a disclaimer that this is not a substitute for professional medical advice.
        4. If the urgency is EMERGENCY, you MUST include language directing the person to call emergency services.
        5. Your guidance must be safe, calm, clear, and appropriate for a non-medical audience.
        6. Do NOT suggest specific prescription medication doses or treatments.
        7. For suicidal ideation: always direct to crisis services, never provide means.
        8. {$langLabel}
        9. HEALTHCARE ACCESS CONTEXT: {$accessLabel}
           - If access is 'pharmacy' or 'none': suggest safe, practical home-based or over-the-counter alternatives where appropriate.
           - Always clearly note when something requires professional care that may not be accessible.
           - Suggest telemedicine or phone-based helplines as alternatives where in-person care is unavailable.
        
        TRIAGE CONTEXT (do NOT change these values):
        - Urgency level (set by rules engine): {$urgency}
        - Risk score: {$score}/100
        - Patient age band: {$ageBand}
        - Reported comorbidities: {$comorbids}
        - Triggered rules: {$rules}
        - Healthcare access level: {$access}
        
        PATIENT REPORTED SYMPTOMS:
        "{$symptoms}"
        
        YOUR TASK — produce EVERY field below:
        1. Identify and normalise the symptom categories from the text (do not add new symptoms).
        2. Write a brief, empathetic 2-3 sentence clinical summary suitable for a healthcare worker.
        3. Write clear, step-by-step patient guidance aligned with urgency level {$urgency}.
           - EMERGENCY: start with "Call emergency services immediately."
           - URGENT: start with "Please seek medical attention today."
           - ROUTINE: start with "We recommend you see a doctor within the next 1-3 days."
           - SELF-CARE: start with "Based on your symptoms, you can manage this at home."
        4. Always end your guidance with: "⚕ Disclaimer: This is not a substitute for professional medical advice. If in doubt, seek help."
        5. List 3-5 specific signs or symptoms the patient should actively watch for over the next 24-72 hours (what_to_monitor).
        6. List 3-4 things that typically make this type of condition worse — activities, foods, behaviours to avoid (what_makes_worse).
        7. Write 2-3 clear, specific conditions under which the patient MUST escalate to emergency or urgent care immediately (when_to_escalate).
        
        RESPOND WITH VALID JSON ONLY. No prose before or after. Format:
        {
          "normalized_symptoms": "comma-separated symptom categories",
          "clinical_summary": "2-3 sentence summary for healthcare workers",
          "patient_guidance": "step-by-step guidance for patient",
          "what_to_monitor": ["sign 1", "sign 2", "sign 3"],
          "what_makes_worse": ["factor 1", "factor 2", "factor 3"],
          "when_to_escalate": ["condition 1", "condition 2"],
          "language_note": "language code used"
        }
        PROMPT;
    }

    private function callApi(string $prompt): array
    {
        $body = json_encode([
            'contents' => [
                ['parts' => [['text' => $prompt]]]
            ],
            'generationConfig' => [
                'temperature'     => 0.2,
                'maxOutputTokens' => 800,
                'responseMimeType' => 'application/json',
            ],
            'safetySettings' => [
                ['category' => 'HARM_CATEGORY_DANGEROUS_CONTENT', 'threshold' => 'BLOCK_MEDIUM_AND_ABOVE'],
                ['category' => 'HARM_CATEGORY_HATE_SPEECH',       'threshold' => 'BLOCK_MEDIUM_AND_ABOVE'],
                ['category' => 'HARM_CATEGORY_HARASSMENT',        'threshold' => 'BLOCK_MEDIUM_AND_ABOVE'],
            ],
        ]);

        $url = $this->endpoint . '?key=' . urlencode($this->apiKey);

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $body,
            CURLOPT_TIMEOUT        => $this->timeoutSeconds,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        ]);

        $responseStr = curl_exec($ch);
        $httpCode    = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError   = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            throw new \RuntimeException("cURL error: {$curlError}");
        }
        if ($httpCode !== 200) {
            throw new \RuntimeException("Gemini API returned HTTP {$httpCode}");
        }

        $decoded = json_decode($responseStr, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new \RuntimeException('Invalid JSON from Gemini API');
        }

        return $decoded;
    }

    private function parseResponse(array $response): ?array
    {
        $text = $response['candidates'][0]['content']['parts'][0]['text'] ?? null;
        if ($text === null) {
            return null;
        }

        // Strip markdown code fences if present
        $text = preg_replace('/^```(?:json)?\s*/i', '', trim($text));
        $text = preg_replace('/\s*```$/', '', $text);

        $parsed = json_decode($text, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return null;
        }

        return [
            'normalized_symptoms' => $parsed['normalized_symptoms'] ?? '',
            'guidance'            => $parsed['patient_guidance']    ?? '',
            'clinical_summary'    => $parsed['clinical_summary']    ?? '',
            'language_note'       => $parsed['language_note']       ?? 'en',
            'what_to_monitor'     => array_values((array)($parsed['what_to_monitor']  ?? [])),
            'what_makes_worse'    => array_values((array)($parsed['what_makes_worse'] ?? [])),
            'when_to_escalate'    => array_values((array)($parsed['when_to_escalate'] ?? [])),
        ];
    }

    /** Static guidance templates for when Gemini is unavailable */
    private function fallback(array $data): array
    {
        $urgency = $data['urgency_level'];
        $guidance = match ($urgency) {
            'EMERGENCY' => "⚠ EMERGENCY: Call emergency services (999 / 911 / 112) immediately. Do not drive yourself. Follow the operator's instructions. ⚕ Disclaimer: This is not a substitute for professional medical advice.",
            'URGENT'    => "⚠ URGENT: Please seek medical attention today at an urgent care centre or emergency department. Do not ignore these symptoms. Monitor for any rapid worsening. ⚕ Disclaimer: This is not a substitute for professional medical advice.",
            'ROUTINE'   => "We recommend you see a doctor within the next 1–3 days. Rest, stay hydrated, and take over-the-counter pain relief if appropriate. Contact a nurse helpline if you are concerned. ⚕ Disclaimer: This is not a substitute for professional medical advice.",
            default     => "Based on your symptoms, you can manage this at home with rest and fluids. Take over-the-counter remedies as directed. Seek pharmacy advice if needed. Return here if symptoms worsen. ⚕ Disclaimer: This is not a substitute for professional medical advice.",
        };

        return [
            'normalized_symptoms' => 'Normalisation unavailable (AI offline)',
            'guidance'            => $guidance,
            'clinical_summary'    => 'AI summary unavailable — rules engine assessment only.',
            'language_note'       => 'en',
            'used_fallback'       => true,
            'what_to_monitor'     => match ($urgency) {
                'EMERGENCY' => ['Any loss of consciousness', 'Worsening pain or new symptoms', 'Difficulty breathing'],
                'URGENT'    => ['Temperature rising above 39°C (102°F)', 'Symptoms not improving within 6 hours', 'Any new or worsening symptoms'],
                'ROUTINE'   => ['Fever developing or worsening', 'Symptoms lasting more than 7 days', 'Any sudden change in condition'],
                default     => ['Symptoms lasting more than 3 days', 'Fever above 38°C', 'Feeling significantly worse'],
            },
            'what_makes_worse'    => match ($urgency) {
                'EMERGENCY' => ['Any physical exertion', 'Delaying calling emergency services', 'Moving the patient unnecessarily'],
                'URGENT'    => ['Ignoring symptoms and waiting', 'Strenuous physical activity', 'Alcohol or smoking'],
                'ROUTINE'   => ['Poor sleep and stress', 'Dehydration', 'Skipping meals', 'Overexertion before recovery'],
                default     => ['Overexertion', 'Poor hydration', 'Irregular sleep', 'Ignoring rest recommendations'],
            },
            'when_to_escalate'    => match ($urgency) {
                'EMERGENCY' => ['Symptoms worsen at any point — call 999/911/112 immediately', 'Person becomes unconscious or stops breathing'],
                'URGENT'    => ['Symptoms worsen rapidly or new symptoms appear', 'You are unable to reach a doctor within a few hours', 'Fever rises above 39.5°C (103°F)'],
                'ROUTINE'   => ['Symptoms do not improve within 3–5 days of home care', 'Fever develops above 38.5°C', 'Any new severe or alarming symptoms appear'],
                default     => ['Symptoms persist beyond 48–72 hours without improvement', 'Develop a fever, severe pain, or breathing difficulty'],
            },
        ];
    }
}

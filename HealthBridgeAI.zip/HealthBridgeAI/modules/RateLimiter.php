<?php

declare(strict_types=1);
/**
 * HealthBridge AI — IP-based Rate Limiter
 * Uses INSERT ... ON DUPLICATE KEY UPDATE to avoid race-condition
 * duplicate-key errors on the unique (ip_address, endpoint) index.
 */
require_once __DIR__ . '/../config/database.php';

class RateLimiter
{
    private static array $limits = [
        'triage'  => 10,   // per minute
        'sync'    => 20,
        'auth'    => 10,   // raised slightly so normal login+retry doesn't trip it
        'default' => 30,
    ];

    /**
     * Check rate limit. Returns true if request is allowed, false if exceeded.
     */
    public static function check(string $endpoint): bool
    {
        $ip    = self::getIp();
        $limit = self::$limits[$endpoint] ?? self::$limits['default'];
        $db    = getDb();

        // Clean stale entries older than 2 minutes (best-effort, non-fatal)
        try {
            $db->prepare("DELETE FROM rate_limits WHERE window_start < DATE_SUB(NOW(), INTERVAL 2 MINUTE)")
                ->execute();
        } catch (Throwable) {
        }

        // Atomic upsert: if no row exists, insert with hit_count=1.
        // If a row exists for this IP+endpoint within the current minute,
        // increment the counter. If the window has expired, reset to 1.
        $db->prepare(
            "INSERT INTO rate_limits (ip_address, endpoint, hit_count, window_start)
             VALUES (:ip, :ep, 1, NOW())
             ON DUPLICATE KEY UPDATE
               hit_count    = IF(window_start >= DATE_SUB(NOW(), INTERVAL 1 MINUTE), hit_count + 1, 1),
               window_start = IF(window_start >= DATE_SUB(NOW(), INTERVAL 1 MINUTE), window_start, NOW())"
        )->execute([':ip' => $ip, ':ep' => $endpoint]);

        // Read back the current count for this IP+endpoint
        $stmt = $db->prepare(
            "SELECT hit_count FROM rate_limits WHERE ip_address = :ip AND endpoint = :ep LIMIT 1"
        );
        $stmt->execute([':ip' => $ip, ':ep' => $endpoint]);
        $count = (int)($stmt->fetchColumn() ?: 0);

        return $count <= $limit;
    }

    /** Send 429 and exit */
    public static function abort(): never
    {
        http_response_code(429);
        header('Content-Type: application/json');
        header('Retry-After: 60');
        echo json_encode(['error' => 'Too many requests. Please wait a moment and try again.']);
        exit;
    }

    private static function getIp(): string
    {
        foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'] as $k) {
            $v = $_SERVER[$k] ?? '';
            if ($v) {
                return trim(explode(',', $v)[0]);
            }
        }
        return '0.0.0.0';
    }
}

<?php

declare(strict_types=1);
/**
 * HealthBridge AI — Auth Module
 */
require_once __DIR__ . '/../config/database.php';

class Auth
{
    /** Start a secure session once */
    public static function startSession(): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_set_cookie_params([
                'lifetime' => 0,
                'path'     => '/',
                'secure'   => isset($_SERVER['HTTPS']),
                'httponly' => true,
                'samesite' => 'Lax',
            ]);
            session_start();
        }
    }

    /** Attempt login — returns user array or null */
    public static function login(string $email, string $password): ?array
    {
        $db   = getDb();
        $stmt = $db->prepare('SELECT id, name, email, password_hash, role FROM users WHERE email = :email AND is_active = 1 LIMIT 1');
        $stmt->execute([':email' => strtolower(trim($email))]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($password, $user['password_hash'])) {
            return null;
        }

        // Update last login
        $db->prepare('UPDATE users SET last_login = NOW() WHERE id = :id')->execute([':id' => $user['id']]);

        self::startSession();
        session_regenerate_id(true);
        $_SESSION['user_id']   = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['loggedIn']  = true;

        return $user;
    }

    /** Destroy session */
    public static function logout(): void
    {
        self::startSession();
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                time() - 42000,
                $params['path'],
                $params['domain'],
                $params['secure'],
                $params['httponly']
            );
        }
        session_destroy();
    }

    /** Require staff to be logged in (JSON APIs) */
    public static function requireStaff(): void
    {
        self::startSession();
        if (empty($_SESSION['loggedIn'])) {
            http_response_code(401);
            header('Content-Type: application/json');
            echo json_encode(['error' => 'Unauthorised. Staff login required.']);
            exit;
        }
    }

    public static function currentUser(): ?array
    {
        self::startSession();
        if (empty($_SESSION['loggedIn'])) {
            return null;
        }
        return [
            'id'   => $_SESSION['user_id'],
            'name' => $_SESSION['user_name'],
            'role' => $_SESSION['user_role'],
        ];
    }

    public static function isLoggedIn(): bool
    {
        self::startSession();
        return !empty($_SESSION['loggedIn']);
    }
}

<?php

declare(strict_types=1);
/**
 * HealthBridge AI — /api/auth.php
 * POST  action=login|logout|check
 */
require_once __DIR__ . '/../config/env.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../modules/Auth.php';
require_once __DIR__ . '/../modules/RateLimiter.php';

header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method Not Allowed']);
    exit;
}

// ── Top-level guard: ALL errors return JSON, never an HTML page ───────────────
try {

    $body   = json_decode(file_get_contents('php://input'), true) ?? [];
    $action = trim($body['action'] ?? '');

    // Rate-limit only write actions (check fires on every page load, no need to limit)
    if ($action !== 'check' && !RateLimiter::check('auth')) {
        RateLimiter::abort();
    }

    // ── Login ─────────────────────────────────────────────────────────────────
    if ($action === 'login') {
        $email    = trim(strip_tags($body['email']    ?? ''));
        $password = $body['password'] ?? '';

        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || empty($password)) {
            http_response_code(422);
            echo json_encode(['error' => 'Valid email and password required.']);
            exit;
        }

        $user = Auth::login($email, $password);
        if (!$user) {
            http_response_code(401);
            echo json_encode(['error' => 'Invalid credentials. Try staff@healthbridge.ai / Demo1234!']);
            exit;
        }

        echo json_encode([
            'success' => true,
            'user'    => ['id' => $user['id'], 'name' => $user['name'], 'role' => $user['role']],
        ]);
        exit;
    }

    // ── Logout ────────────────────────────────────────────────────────────────
    if ($action === 'logout') {
        Auth::logout();
        echo json_encode(['success' => true]);
        exit;
    }

    // ── Check session ─────────────────────────────────────────────────────────
    if ($action === 'check') {
        Auth::startSession();
        echo json_encode(['logged_in' => Auth::isLoggedIn(), 'user' => Auth::currentUser()]);
        exit;
    }

    http_response_code(400);
    echo json_encode(['error' => 'Unknown action.']);
} catch (Throwable $e) {
    // DB down, misconfigured .env, PHP error — always return JSON
    http_response_code(500);
    echo json_encode([
        'error'   => 'Server error: ' . $e->getMessage(),
        'success' => false,
    ]);
}

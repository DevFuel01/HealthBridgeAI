<?php

declare(strict_types=1);
/**
 * HealthBridge AI — /api/analytics.php
 * GET — returns aggregated analytics for the staff dashboard.
 */
require_once __DIR__ . '/../config/env.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../modules/Auth.php';
require_once __DIR__ . '/../modules/RateLimiter.php';

header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['error' => 'Method Not Allowed']);
    exit;
}

Auth::requireStaff();
if (!RateLimiter::check('default')) {
    RateLimiter::abort();
}

try {
    $db = getDb();

    // ── 1. Case count stats ────────────────────────────────────────────────────
    $totals = $db->query(
        "SELECT
            COUNT(*)                                                      AS total,
            SUM(DATE(created_at) = CURDATE())                            AS today,
            SUM(created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY))           AS this_week,
            SUM(status = 'RESOLVED')                                     AS resolved,
            SUM(status = 'NEW')                                          AS new_cases,
            SUM(status = 'REVIEWING')                                    AS reviewing
         FROM cases"
    )->fetch();

    // ── 2. Urgency distribution ────────────────────────────────────────────────
    $urgencyRows = $db->query(
        "SELECT urgency_level, COUNT(*) AS cnt
         FROM cases GROUP BY urgency_level ORDER BY FIELD(urgency_level,'EMERGENCY','URGENT','ROUTINE','SELF-CARE')"
    )->fetchAll();

    $urgency = [];
    foreach ($urgencyRows as $r) {
        $urgency[$r['urgency_level']] = (int)$r['cnt'];
    }

    // ── 3. Cases per day — last 14 days (trend) ────────────────────────────────
    $trendRows = $db->query(
        "SELECT DATE(created_at) AS day, COUNT(*) AS cnt
         FROM cases
         WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 13 DAY)
         GROUP BY DATE(created_at)
         ORDER BY day ASC"
    )->fetchAll();

    // Fill in zero-count days so the chart is continuous
    $trend = [];
    for ($i = 13; $i >= 0; $i--) {
        $d = date('Y-m-d', strtotime("-{$i} days"));
        $trend[$d] = 0;
    }
    foreach ($trendRows as $r) {
        $trend[$r['day']] = (int)$r['cnt'];
    }

    // ── 4. Average resolution time (NEW → RESOLVED via audit_logs) ────────────
    $resTime = $db->query(
        "SELECT AVG(
             TIMESTAMPDIFF(MINUTE,
                 c.created_at,
                 (SELECT al.created_at
                  FROM audit_logs al
                  WHERE al.action = 'case_status_update'
                    AND JSON_UNQUOTE(JSON_EXTRACT(al.meta_json,'$.case_id')) = CAST(c.id AS CHAR)
                    AND JSON_UNQUOTE(JSON_EXTRACT(al.meta_json,'$.new_status')) = 'RESOLVED'
                  ORDER BY al.created_at ASC LIMIT 1)
             )
         ) AS avg_minutes
         FROM cases c
         WHERE c.status = 'RESOLVED'"
    )->fetchColumn();

    $avgMinutes = $resTime !== null ? round((float)$resTime) : null;

    // ── 5. Symptom keyword frequency ─────────────────────────────────────────
    // Pull last 200 cases' symptoms_text and count common clinical keywords
    $sympRows = $db->query(
        "SELECT symptoms_text FROM cases ORDER BY created_at DESC LIMIT 200"
    )->fetchAll(PDO::FETCH_COLUMN);

    $keywords = [
        'headache',
        'fever',
        'cough',
        'chest pain',
        'shortness of breath',
        'vomiting',
        'nausea',
        'diarrhea',
        'dizziness',
        'fatigue',
        'pain',
        'rash',
        'swelling',
        'bleeding',
        'unconscious',
        'seizure',
        'breathless',
        'throat',
        'back pain',
        'abdominal',
        'stomach',
        'infection',
        'fracture',
        'injury',
    ];

    $freq = [];
    foreach ($keywords as $kw) {
        $count = 0;
        foreach ($sympRows as $text) {
            $count += substr_count(strtolower($text), $kw);
        }
        if ($count > 0) {
            $freq[$kw] = $count;
        }
    }
    arsort($freq);
    $freq = array_slice($freq, 0, 10, true); // top 10

    echo json_encode([
        'success'       => true,
        'totals'        => $totals,
        'urgency'       => $urgency,
        'trend'         => $trend,
        'avg_resolution_minutes' => $avgMinutes,
        'symptom_freq'  => $freq,
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Server error: ' . $e->getMessage(), 'success' => false]);
}

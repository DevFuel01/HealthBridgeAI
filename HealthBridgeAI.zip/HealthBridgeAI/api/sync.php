<?php

declare(strict_types=1);
/**
 * HealthBridge AI — POST /api/sync
 * Accept array of offline-queued cases, run triage pipeline, return results.
 */
require_once __DIR__ . '/../config/env.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../modules/RulesEngine.php';
require_once __DIR__ . '/../modules/GeminiClient.php';
require_once __DIR__ . '/../modules/RateLimiter.php';

header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method Not Allowed']);
    exit;
}

if (!RateLimiter::check('sync')) {
    RateLimiter::abort();
}

$body  = json_decode(file_get_contents('php://input'), true);
$cases = $body['cases'] ?? [];

if (!is_array($cases) || empty($cases)) {
    http_response_code(422);
    echo json_encode(['error' => 'No cases provided.']);
    exit;
}

// Process max 20 cases per sync call
$cases   = array_slice($cases, 0, 20);
$results = [];
$db      = getDb();
$gemini  = new GeminiClient();

foreach ($cases as $caseInput) {
    $offlineId     = trim(strip_tags($caseInput['offline_id'] ?? ''));
    $symptomsText  = trim(strip_tags($caseInput['symptoms_text'] ?? ''));
    if (mb_strlen($symptomsText) < 3) {
        $results[] = ['offline_id' => $offlineId, 'success' => false, 'error' => 'Symptoms too short'];
        continue;
    }

    $severity        = max(1, min(5, (int)($caseInput['severity'] ?? 1)));
    $duration        = trim(strip_tags($caseInput['duration'] ?? '<24h'));
    $ageBand         = in_array($caseInput['age_band'] ?? '', ['child', 'adult', 'elderly']) ? $caseInput['age_band'] : 'adult';
    $isPregnant      = (bool)($caseInput['pregnancy_status'] ?? false);
    $comorbidities   = array_slice(array_map(fn($c) => trim(strip_tags((string)$c)), (array)($caseInput['comorbidities'] ?? [])), 0, 10);
    $selectedRedFlags = array_slice(array_map(fn($f) => trim(strip_tags((string)$f)), (array)($caseInput['red_flags'] ?? [])), 0, 15);
    $language        = preg_match('/^[a-z]{2}(-[A-Z]{2})?$/', $caseInput['language'] ?? '') ? $caseInput['language'] : 'en';

    $rulesResult = RulesEngine::evaluate([
        'symptoms_text'   => $symptomsText,
        'severity'        => $severity,
        'duration'        => $duration,
        'age_band'        => $ageBand,
        'pregnancy_status' => $isPregnant,
        'comorbidities'   => $comorbidities,
        'red_flags'       => $selectedRedFlags,
    ]);

    $geminiData = $gemini->generateGuidance([
        'symptoms_text'   => $symptomsText,
        'urgency_level'   => $rulesResult['urgency_level'],
        'risk_score'      => $rulesResult['risk_score'],
        'triggered_rules' => $rulesResult['triggered_rules'],
        'age_band'        => $ageBand,
        'comorbidities'   => $comorbidities,
        'language'        => $language,
    ]);

    $publicId = strtoupper(substr(bin2hex(random_bytes(6)), 0, 12));

    try {
        $stmt = $db->prepare(
            "INSERT INTO cases (public_case_id, age_band, symptoms_text, severity, duration, comorbidities_json, pregnancy_status, red_flags_json, urgency_level, risk_score, triggered_rules_json, ai_summary, ai_guidance, language, synced_from_offline)
             VALUES (:pub_id,:age_band,:symptoms,:severity,:duration,:comorbidities,:pregnancy,:red_flags,:urgency,:score,:triggered,:ai_summary,:ai_guidance,:language,1)"
        );
        $stmt->execute([
            ':pub_id'       => $publicId,
            ':age_band'     => $ageBand,
            ':symptoms'     => mb_substr($symptomsText, 0, 2000),
            ':severity'     => $severity,
            ':duration'     => $duration,
            ':comorbidities' => json_encode($comorbidities),
            ':pregnancy'    => (int)$isPregnant,
            ':red_flags'    => json_encode($selectedRedFlags),
            ':urgency'      => $rulesResult['urgency_level'],
            ':score'        => $rulesResult['risk_score'],
            ':triggered'    => json_encode($rulesResult['triggered_rules']),
            ':ai_summary'   => $geminiData['clinical_summary'],
            ':ai_guidance'  => $geminiData['guidance'],
            ':language'     => $language,
        ]);
        $caseId = (int)$db->lastInsertId();
    } catch (\PDOException $e) {
        error_log('[sync.php] DB error: ' . $e->getMessage());
        $caseId = null;
    }

    $results[] = [
        'offline_id'      => $offlineId,
        'success'         => true,
        'public_case_id'  => $publicId,
        'case_id'         => $caseId,
        'urgency_level'   => $rulesResult['urgency_level'],
        'risk_score'      => $rulesResult['risk_score'],
        'is_emergency'    => $rulesResult['is_emergency'],
    ];
}

echo json_encode(['success' => true, 'results' => $results, 'processed' => count($results)]);

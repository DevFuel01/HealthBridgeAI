<?php

declare(strict_types=1);
/**
 * HealthBridge AI — POST /api/triage
 * Main triage endpoint. Rules Engine runs deterministically first; Gemini is advisory.
 */

require_once __DIR__ . '/../config/env.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../modules/RulesEngine.php';
require_once __DIR__ . '/../modules/GeminiClient.php';
require_once __DIR__ . '/../modules/RateLimiter.php';

header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');

// CORS headers (restrict in production to your domain)
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method Not Allowed']);
    exit;
}

// Rate limit
if (!RateLimiter::check('triage')) {
    RateLimiter::abort();
}

// Parse body
$body = json_decode(file_get_contents('php://input'), true);
if (!$body) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON body']);
    exit;
}

// ── Validate & sanitise ───────────────────────────────────────────────────────
$symptomsText   = trim(strip_tags($body['symptoms_text'] ?? ''));
$severity       = max(1, min(5, (int)($body['severity']  ?? 1)));
$duration       = trim(strip_tags($body['duration']       ?? '<24h'));
$ageBand        = in_array($body['age_band'] ?? '', ['child', 'adult', 'elderly']) ? $body['age_band'] : 'adult';
$gender         = in_array($body['gender']   ?? '', ['male', 'female', 'other', 'prefer_not']) ? $body['gender'] : null;
$isPregnant     = (bool)($body['pregnancy_status'] ?? false);
$comorbidities  = array_slice(array_map(fn($c) => trim(strip_tags((string)$c)), (array)($body['comorbidities'] ?? [])), 0, 10);
$selectedRedFlags = array_slice(array_map(fn($f) => trim(strip_tags((string)$f)), (array)($body['red_flags'] ?? [])), 0, 15);
$patientName    = trim(strip_tags($body['patient_name'] ?? ''));
$language       = preg_match('/^[a-z]{2}(-[A-Z]{2})?$/', $body['language'] ?? '') ? $body['language'] : 'en';
$offlineId      = trim(strip_tags($body['offline_id'] ?? '')); // client-generated offline queue ID
$lowBandwidth   = (bool)($body['low_bandwidth']   ?? false);
$healthcareAccess = in_array($body['healthcare_access'] ?? '', ['full', 'clinic', 'pharmacy', 'none'])
    ? $body['healthcare_access'] : 'full';

if (mb_strlen($symptomsText) < 3) {
    http_response_code(422);
    echo json_encode(['error' => 'Symptoms description is required (minimum 3 characters).']);
    exit;
}
if (mb_strlen($symptomsText) > 2000) {
    $symptomsText = mb_substr($symptomsText, 0, 2000);
}

// ── Rules Engine (MUST run first) ────────────────────────────────────────────
$rulesResult = RulesEngine::evaluate([
    'symptoms_text'   => $symptomsText,
    'severity'        => $severity,
    'duration'        => $duration,
    'age_band'        => $ageBand,
    'pregnancy_status' => $isPregnant,
    'comorbidities'   => $comorbidities,
    'red_flags'       => $selectedRedFlags,
]);

// ── Gemini AI (advisory only; skipped in low-bandwidth mode) ─────────────────
$geminiClient = new GeminiClient();
if ($lowBandwidth) {
    // Skip AI entirely — use static fallback to conserve bandwidth
    $geminiData = $geminiClient->getFallbackOnly([
        'urgency_level'     => $rulesResult['urgency_level'],
        'healthcare_access' => $healthcareAccess,
    ]);
} else {
    $geminiData = $geminiClient->generateGuidance([
        'symptoms_text'     => $symptomsText,
        'urgency_level'     => $rulesResult['urgency_level'],
        'risk_score'        => $rulesResult['risk_score'],
        'triggered_rules'   => $rulesResult['triggered_rules'],
        'age_band'          => $ageBand,
        'comorbidities'     => $comorbidities,
        'language'          => $language,
        'healthcare_access' => $healthcareAccess,
    ]);
}

// ── Generate public case ID ───────────────────────────────────────────────────
$publicId = strtoupper(substr(bin2hex(random_bytes(6)), 0, 12));

// ── Save to database ──────────────────────────────────────────────────────────
try {
    $db = getDb();
    $stmt = $db->prepare(
        "INSERT INTO cases
         (public_case_id, patient_name, age_band, gender, symptoms_text, severity, duration,
          comorbidities_json, pregnancy_status, red_flags_json, urgency_level, risk_score,
          triggered_rules_json, ai_summary, ai_guidance, language, synced_from_offline)
         VALUES
         (:pub_id, :patient_name, :age_band, :gender, :symptoms_text, :severity, :duration,
          :comorbidities, :pregnancy, :red_flags, :urgency, :score,
          :triggered, :ai_summary, :ai_guidance, :language, :offline)"
    );
    $stmt->execute([
        ':pub_id'       => $publicId,
        ':patient_name' => $patientName ?: null,
        ':age_band'     => $ageBand,
        ':gender'       => $gender,
        ':symptoms_text' => $symptomsText,
        ':severity'     => $severity,
        ':duration'     => $duration,
        ':comorbidities' => json_encode($comorbidities),
        ':pregnancy'    => (int)$isPregnant,
        ':red_flags'    => json_encode($selectedRedFlags),
        ':urgency'      => $rulesResult['urgency_level'],
        ':score'        => $rulesResult['risk_score'],
        ':triggered'    => json_encode($rulesResult['triggered_rules']),
        ':ai_summary'   => $geminiData['clinical_summary'],
        ':ai_guidance'  => $geminiData['guidance'],
        ':language'     => $language,
        ':offline'      => 0,
    ]);
    $caseId = (int)$db->lastInsertId();
} catch (\PDOException $e) {
    error_log('[triage.php] DB error: ' . $e->getMessage());
    // Non-fatal — return result without DB ID
    $caseId = null;
}

// ── Response ──────────────────────────────────────────────────────────────────
echo json_encode([
    'success'             => true,
    'public_case_id'      => $publicId,
    'case_id'             => $caseId,
    'offline_id'          => $offlineId,
    'urgency_level'       => $rulesResult['urgency_level'],
    'risk_score'          => $rulesResult['risk_score'],
    'is_emergency'        => $rulesResult['is_emergency'],
    'triggered_rules'     => $rulesResult['triggered_rules'],
    'explainer'           => $rulesResult['explainer'],
    'first_aid_steps'     => $rulesResult['first_aid_steps'],
    'crisis_resources'    => $rulesResult['crisis_resources'],
    'ai_summary'          => $geminiData['clinical_summary'],
    'ai_guidance'         => $geminiData['guidance'],
    'normalized_symptoms' => $geminiData['normalized_symptoms'],
    'what_to_monitor'     => $geminiData['what_to_monitor']  ?? [],
    'what_makes_worse'    => $geminiData['what_makes_worse'] ?? [],
    'when_to_escalate'    => $geminiData['when_to_escalate'] ?? [],
    'used_ai_fallback'    => $geminiData['used_fallback'],
]);

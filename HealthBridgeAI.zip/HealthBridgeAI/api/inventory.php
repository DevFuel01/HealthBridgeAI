<?php

declare(strict_types=1);
/**
 * HealthBridge AI — /api/inventory.php
 * GET   — list inventory items (staff only)
 * PATCH — update stock level
 */
require_once __DIR__ . '/../config/env.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../modules/Auth.php';
require_once __DIR__ . '/../modules/RateLimiter.php';

header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PATCH, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// ── Top-level guard — always return JSON, never an HTML error page ─────────────
try {

    Auth::requireStaff();

    if (!RateLimiter::check('default')) {
        RateLimiter::abort();
    }

    $db     = getDb();
    $method = $_SERVER['REQUEST_METHOD'];

    // ── GET list ───────────────────────────────────────────────────────────────
    if ($method === 'GET') {
        $stmt  = $db->query(
            'SELECT id, item_name, category, stock_level, threshold, unit, updated_at
             FROM inventory ORDER BY category, item_name'
        );
        $items = $stmt->fetchAll();
        foreach ($items as &$item) {
            $item['is_low'] = ((int)$item['stock_level'] <= (int)$item['threshold']);
        }
        echo json_encode(['success' => true, 'items' => $items]);
        exit;
    }

    // ── PATCH update stock ─────────────────────────────────────────────────────
    if ($method === 'PATCH') {
        $body       = json_decode(file_get_contents('php://input'), true) ?? [];
        $id         = (int)($body['id'] ?? 0);
        $stockLevel = max(0, (int)($body['stock_level'] ?? 0));

        if (!$id) {
            http_response_code(422);
            echo json_encode(['error' => 'Item id required.']);
            exit;
        }

        $stmt = $db->prepare('UPDATE inventory SET stock_level = :stock WHERE id = :id');
        $stmt->execute([':stock' => $stockLevel, ':id' => $id]);

        // rowCount() is intentionally NOT used here — MySQL returns 0 when the
        // new value equals the existing value, which is a valid no-op update.
        // Audit log — non-fatal
        try {
            $user = Auth::currentUser();
            $db->prepare(
                'INSERT INTO audit_logs (user_id, action, meta_json, ip_address)
                 VALUES (:uid, :action, :meta, :ip)'
            )->execute([
                ':uid'    => $user['id'] ?? null,
                ':action' => 'inventory_update',
                ':meta'   => json_encode(['item_id' => $id, 'new_stock' => $stockLevel]),
                ':ip'     => $_SERVER['REMOTE_ADDR'] ?? '',
            ]);
        } catch (Throwable) {
        }

        echo json_encode(['success' => true]);
        exit;
    }

    http_response_code(405);
    echo json_encode(['error' => 'Method Not Allowed']);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Server error: ' . $e->getMessage(), 'success' => false]);
}

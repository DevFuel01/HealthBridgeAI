<?php

declare(strict_types=1);
/**
 * HealthBridge AI — /api/cases.php
 * GET    — list cases (staff only, with filters)
 * GET ?id= — single case
 * PATCH  — update case status
 */
require_once __DIR__ . '/../config/env.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../modules/Auth.php';
require_once __DIR__ . '/../modules/RateLimiter.php';

header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, PATCH, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

Auth::requireStaff();
if (!RateLimiter::check('default')) {
    RateLimiter::abort();
}

$db     = getDb();
$method = $_SERVER['REQUEST_METHOD'];

// ── GET list or single ────────────────────────────────────────────────────────
if ($method === 'GET') {
    $id      = isset($_GET['id'])      ? (int)$_GET['id']      : null;
    $history = isset($_GET['history']) ? (bool)$_GET['history'] : false;

    // ── GET ?history=1&id=X  — case status change timeline ───────────────────
    if ($id && $history) {
        $stmt = $db->prepare(
            "SELECT al.id, al.action, al.meta_json, al.created_at,
                    u.name AS staff_name
             FROM   audit_logs al
             LEFT JOIN users u ON u.id = al.user_id
             WHERE  al.action = 'case_status_update'
               AND  JSON_UNQUOTE(JSON_EXTRACT(al.meta_json, '$.case_id')) = :case_id
             ORDER  BY al.created_at ASC"
        );
        $stmt->execute([':case_id' => $id]);
        $rows  = $stmt->fetchAll();
        $events = array_map(function ($row) {
            $meta = json_decode($row['meta_json'] ?? '{}', true);
            return [
                'id'          => $row['id'],
                'new_status'  => $meta['new_status'] ?? '?',
                'staff_name'  => $row['staff_name'] ?? 'Unknown staff',
                'created_at'  => $row['created_at'],
            ];
        }, $rows);
        echo json_encode(['success' => true, 'events' => $events]);
        exit;
    }

    if ($id) {
        $stmt = $db->prepare('SELECT * FROM cases WHERE id = :id LIMIT 1');
        $stmt->execute([':id' => $id]);
        $case = $stmt->fetch();
        if (!$case) {
            http_response_code(404);
            echo json_encode(['error' => 'Not found']);
            exit;
        }
        // Decode JSON columns
        foreach (['comorbidities_json', 'red_flags_json', 'triggered_rules_json'] as $col) {
            $case[$col] = json_decode($case[$col] ?? '[]', true);
        }
        // Fetch low-inventory items for advisory
        $invStmt = $db->query('SELECT item_name, stock_level, threshold FROM inventory WHERE stock_level <= threshold ORDER BY item_name');
        $lowStock = $invStmt->fetchAll();
        echo json_encode(['success' => true, 'case' => $case, 'low_stock' => $lowStock]);
        exit;
    }

    // List with filters
    $where  = ['1=1'];
    $params = [];

    if (!empty($_GET['urgency']) && in_array($_GET['urgency'], ['EMERGENCY', 'URGENT', 'ROUTINE', 'SELF-CARE'], true)) {
        $where[]  = 'urgency_level = :urgency';
        $params[':urgency'] = $_GET['urgency'];
    }
    if (!empty($_GET['status']) && in_array($_GET['status'], ['NEW', 'REVIEWING', 'RESOLVED'], true)) {
        $where[]  = 'status = :status';
        $params[':status'] = $_GET['status'];
    }
    if (!empty($_GET['date_from'])) {
        $where[]  = 'created_at >= :date_from';
        $params[':date_from'] = $_GET['date_from'] . ' 00:00:00';
    }
    if (!empty($_GET['date_to'])) {
        $where[]  = 'created_at <= :date_to';
        $params[':date_to'] = $_GET['date_to'] . ' 23:59:59';
    }

    $page    = max(1, (int)($_GET['page'] ?? 1));
    $perPage = 20;
    $offset  = ($page - 1) * $perPage;
    $whereSql = implode(' AND ', $where);

    $countStmt = $db->prepare("SELECT COUNT(*) FROM cases WHERE {$whereSql}");
    $countStmt->execute($params);
    $total = (int)$countStmt->fetchColumn();

    $stmt = $db->prepare("SELECT id, public_case_id, patient_name, age_band, symptoms_text, severity, duration, urgency_level, risk_score, status, created_at FROM cases WHERE {$whereSql} ORDER BY created_at DESC LIMIT {$perPage} OFFSET {$offset}");
    $stmt->execute($params);
    $cases = $stmt->fetchAll();

    echo json_encode(['success' => true, 'cases' => $cases, 'total' => $total, 'page' => $page, 'per_page' => $perPage]);
    exit;
}

// ── PATCH update status ───────────────────────────────────────────────────────
if ($method === 'PATCH') {
    try {
        $body   = json_decode(file_get_contents('php://input'), true) ?? [];
        $id     = (int)($body['id'] ?? 0);
        $status = trim($body['status'] ?? '');

        if (!$id || !in_array($status, ['NEW', 'REVIEWING', 'RESOLVED'], true)) {
            http_response_code(422);
            echo json_encode(['error' => 'Valid case id and status required.']);
            exit;
        }

        $stmt = $db->prepare('UPDATE cases SET status = :status WHERE id = :id');
        $stmt->execute([':status' => $status, ':id' => $id]);

        if ($stmt->rowCount() === 0) {
            http_response_code(404);
            echo json_encode(['error' => 'Case not found.']);
            exit;
        }

        // Audit log — non-fatal: a failure here must not break the update response
        try {
            $user = Auth::currentUser();
            $uid  = $user['id'] ?? null;
            $db->prepare(
                'INSERT INTO audit_logs (user_id, action, meta_json, ip_address)
                 VALUES (:uid, :action, :meta, :ip)'
            )->execute([
                ':uid'    => $uid,
                ':action' => 'case_status_update',
                ':meta'   => json_encode(['case_id' => $id, 'new_status' => $status]),
                ':ip'     => $_SERVER['REMOTE_ADDR'] ?? '',
            ]);
        } catch (Throwable $auditErr) {
            // Log to error_log but do not surface to client
            error_log('[HealthBridge] Audit log failed: ' . $auditErr->getMessage());
        }

        echo json_encode(['success' => true, 'status' => $status]);
        exit;
    } catch (Throwable $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Server error: ' . $e->getMessage()]);
        exit;
    }
}

http_response_code(405);
echo json_encode(['error' => 'Method Not Allowed']);

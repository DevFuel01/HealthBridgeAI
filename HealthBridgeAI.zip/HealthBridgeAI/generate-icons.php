<?php

/**
 * HealthBridge AI - Icon Generator
 * Run once via CLI: php generate-icons.php
 * Requires GD extension (bundled with XAMPP).
 */

function makeIcon($outPath, $size)
{
    $img = imagecreatetruecolor($size, $size);
    imagesavealpha($img, true);

    $bg = imagecolorallocate($img, 13, 17, 23);
    imagefill($img, 0, 0, $bg);

    for ($x = 0; $x < $size; $x++) {
        $t   = $x / $size;
        $r   = (int)(45  + (129 - 45)  * $t);
        $g   = (int)(212 + (140 - 212) * $t);
        $b   = (int)(191 + (248 - 191) * $t);
        $col = imagecolorallocate($img, $r, $g, $b);
        $pad = (int)($size * 0.14);
        imageline($img, $x, $pad, $x, $size - $pad, $col);
    }

    $white = imagecolorallocate($img, 255, 255, 255);
    $cw    = (int)($size * 0.16);
    $h     = (int)($size * 0.5);
    $arm   = (int)($size * 0.23);
    imagefilledrectangle($img, $h - $cw, $h - $arm, $h + $cw, $h + $arm, $white);
    imagefilledrectangle($img, $h - $arm, $h - $cw, $h + $arm, $h + $cw, $white);

    imagepng($img, $outPath);
    imagedestroy($img);
    echo "Generated: " . $outPath . "\n";
}

$dir = __DIR__ . '/icons';
makeIcon($dir . '/icon-192.png', 192);
makeIcon($dir . '/icon-512.png', 512);
echo "Done.\n";
